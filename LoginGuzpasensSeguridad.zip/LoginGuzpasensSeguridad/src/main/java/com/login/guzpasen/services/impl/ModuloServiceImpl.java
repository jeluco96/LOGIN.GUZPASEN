package com.login.guzpasen.services.impl;


import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.repositories.ModuloRepository;
import com.login.guzpasen.services.ModuloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ModuloServiceImpl implements ModuloService {

    @Autowired
    private ModuloRepository moduloRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Modulo> getAllModulos() {
        return moduloRepository.findAll();
    }

    @Override
    @Transactional
    public Modulo createModulo(Modulo modulo) {
        return moduloRepository.save(modulo);
    }

    @Override
    @Transactional
    public void deleteModulo(Long id) {
        moduloRepository.deleteById(id);
    }
}
