package com.login.guzpasen.services.impl;


import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.repositories.ModuloRepository;
import com.login.guzpasen.repositories.UsuarioRepository;
import com.login.guzpasen.services.UsuarioService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Implementación de la interfaz {@link UsuarioService} que proporciona
 * la lógica de negocio para la gestión de usuarios.
 * <p>
 * Esta clase se encarga de implementar todas las operaciones definidas en la interfaz
 * de servicio, utilizando los repositorios correspondientes para interactuar con la base de datos.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 * @see UsuarioService
 * @see UsuarioRepository
 * @see ModuloRepository
 */
@Service
public class UsuarioServiceImpl implements UsuarioService {

    /**
     * Repositorio para operaciones de persistencia de usuarios.
     */
    @Autowired
    private UsuarioRepository usuarioRepository;

    /**
     * Repositorio para operaciones de persistencia de módulos.
     */
    @Autowired
    private ModuloRepository moduloRepository;

    /**
     * {@inheritDoc}
     * <p>
     * En un entorno de producción, este método debería incluir el
     * encriptado de la contraseña antes de almacenarla en la base de datos.
     * </p>
     */
    @Override
    @Transactional
    public Usuario createUsuario(Usuario usuario) {
        // En un caso real, la contraseña se encriptaría aquí
        return usuarioRepository.save(usuario);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método utiliza la operación findAll() del repositorio para
     * obtener todos los usuarios sin aplicar ningún filtro.
     * </p>
     */
    @Override
    @Transactional(readOnly = true)
    public List<Usuario> getAllUsuarios() {
        return usuarioRepository.findAll();
    }

    /**
     * {@inheritDoc}
     * <p>
     * Método optimizado para lectura mediante la anotación readOnly=true
     * que evita bloquear recursos innecesariamente.
     * </p>
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Usuario> getUsuarioById(Long id) {
        return usuarioRepository.findById(id);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método aprovecha la consulta personalizada definida en el repositorio
     * para buscar por el campo email que tiene restricción de unicidad.
     * </p>
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Usuario> getUsuarioByEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método implementa una actualización parcial (partial update) donde solo
     * se actualizan los campos proporcionados en el objeto usuarioDetails. En el caso
     * de la contraseña, solo se actualiza si se proporciona un valor no vacío.
     * </p>
     * <p>
     * En un entorno de producción, la contraseña nueva debería encriptarse antes
     * de almacenarse en la base de datos.
     * </p>
     * 
     * @throws EntityNotFoundException si no se encuentra el usuario con el ID especificado
     */
    @Override
    @Transactional
    public Usuario updateUsuario(Long id, Usuario usuarioDetails) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado con id: " + id));

        usuario.setNombre(usuarioDetails.getNombre());
        usuario.setApellidos(usuarioDetails.getApellidos());

            // Solo actualizar el email si no es nulo
            if (usuarioDetails.getEmail() != null && !usuarioDetails.getEmail().isEmpty()) {
                usuario.setEmail(usuarioDetails.getEmail());
            }
        usuario.setRol(usuarioDetails.getRol());
        usuario.setActivo(usuarioDetails.isActivo());

        // Solo actualizar la contraseña si se proporciona una nueva
        if (usuarioDetails.getPassword() != null && !usuarioDetails.getPassword().isEmpty()) {
            usuario.setPassword(usuarioDetails.getPassword());
        }

        return usuarioRepository.save(usuario);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método elimina directamente el usuario por su ID sin realizar
     * comprobaciones adicionales. Si el usuario no existe, la operación
     * no falla pero tampoco realiza ninguna acción.
     * </p>
     * <p>
     * En un entorno de producción, podría ser conveniente implementar
     * eliminación lógica (soft delete) en lugar de física.
     * </p>
     */
    @Override
    @Transactional
    public void deleteUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método aprovecha la carga EAGER configurada en la relación ManyToMany
     * de la entidad Usuario para obtener todos los módulos en una sola consulta.
     * </p>
     * 
     * @throws EntityNotFoundException si no se encuentra el usuario con el ID especificado
     */
    @Override
    @Transactional(readOnly = true)
    public Set<Modulo> getModulosByUsuario(Long usuarioId) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado con id: " + usuarioId));
        return usuario.getModulos();
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método agrega un módulo al conjunto de módulos del usuario y guarda
     * la actualización en la base de datos. La relación se gestiona automáticamente
     * a través de la tabla intermedia usuario_modulo.
     * </p>
     * <p>
     * Si el módulo ya estaba asignado al usuario, no se producirá ningún error ya que
     * el método add() del Set no permite duplicados.
     * </p>
     * 
     * @throws EntityNotFoundException si no se encuentra el usuario o el módulo con los IDs especificados
     */
    @Override
    @Transactional
    public Usuario addModuloToUsuario(Long usuarioId, Long moduloId) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado con id: " + usuarioId));
        Modulo modulo = moduloRepository.findById(moduloId)
                .orElseThrow(() -> new EntityNotFoundException("Módulo no encontrado con id: " + moduloId));

        usuario.getModulos().add(modulo);
        return usuarioRepository.save(usuario);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Este método elimina un módulo del conjunto de módulos del usuario y guarda
     * la actualización en la base de datos. La relación se gestiona automáticamente
     * a través de la tabla intermedia usuario_modulo.
     * </p>
     * <p>
     * Si el módulo no estaba asignado al usuario, el método no producirá ningún error,
     * ya que el método remove() del Set simplemente devolverá false sin modificar la colección.
     * </p>
     * 
     * @throws EntityNotFoundException si no se encuentra el usuario o el módulo con los IDs especificados
     */
    @Transactional
    @Override
    public Usuario removeModuloFromUsuario(Long usuarioId, Long moduloId) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado con id: " + usuarioId));
        Modulo modulo = moduloRepository.findById(moduloId)
                .orElseThrow(() -> new EntityNotFoundException("Módulo no encontrado con id: " + moduloId));

        usuario.getModulos().remove(modulo);
        return usuarioRepository.save(usuario);
    }
}
