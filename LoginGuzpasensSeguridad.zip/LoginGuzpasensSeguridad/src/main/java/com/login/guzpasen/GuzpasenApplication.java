package com.login.guzpasen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuzpasenApplication {

    public static void main(String[] args) {
        SpringApplication.run(GuzpasenApplication.class, args);
    }

}
