package com.login.guzpasen.controllers;


import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;



    @PostMapping
    public ResponseEntity<Usuario> createUsuario(@RequestBody Usuario usuario) {
        Usuario savedUsuario = usuarioService.createUsuario(usuario);
        return new ResponseEntity<>(savedUsuario, HttpStatus.CREATED);
    }

    @GetMapping
    public List<Usuario> getAllUsuarios() {
        return usuarioService.getAllUsuarios();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable Long id) {
        return usuarioService.getUsuarioById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<Usuario> getUsuarioByEmail(@PathVariable String email) {
        return usuarioService.getUsuarioByEmail(email)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Usuario> updateUsuario(@PathVariable Long id, @RequestBody Usuario usuarioDetails) {
        try {
            Usuario updatedUsuario = usuarioService.updateUsuario(id, usuarioDetails);
            return ResponseEntity.ok(updatedUsuario);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id) {
        usuarioService.deleteUsuario(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/desactivar")
    public ResponseEntity<Usuario> desactivarUsuario(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
            usuario.setActivo(false);
            Usuario updated = usuarioService.updateUsuario(id, usuario);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}/resetPassword")
    public ResponseEntity<Usuario> resetPassword(@PathVariable Long id, @RequestBody Map<String, String> body) {
        try {
            String newPassword = body.get("password");
            if (newPassword == null || newPassword.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }

            Usuario usuario = usuarioService.getUsuarioById(id)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
            usuario.setPassword(newPassword);
            Usuario updated = usuarioService.updateUsuario(id, usuario);

            // Devolvemos un usuario sin la contraseña por seguridad
            updated.setPassword(null);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{usuarioId}/modulos")
    public ResponseEntity<Set<Modulo>> getModulosByUsuario(@PathVariable Long usuarioId) {
        try {
            return ResponseEntity.ok(usuarioService.getModulosByUsuario(usuarioId));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{usuarioId}/modulos/{moduloId}")
    public ResponseEntity<Usuario> addModuloToUsuario(@PathVariable Long usuarioId, @PathVariable Long moduloId) {
        try {
            return ResponseEntity.ok(usuarioService.addModuloToUsuario(usuarioId, moduloId));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{usuarioId}/modulos/{moduloId}")
    public ResponseEntity<Usuario> removeModuloFromUsuario(@PathVariable Long usuarioId, @PathVariable Long moduloId) {
        try {
            return ResponseEntity.ok(usuarioService.removeModuloFromUsuario(usuarioId, moduloId));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
