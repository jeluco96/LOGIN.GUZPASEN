package com.login.guzpasen.services.impl;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;
import com.login.guzpasen.repositories.TareaRepository;
import com.login.guzpasen.services.TareaService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Implementación de la interfaz {@link TareaService} que proporciona
 * la lógica de negocio para la gestión de tareas.
 * <p>
 * Esta clase se encarga de implementar todas las operaciones definidas en la interfaz
 * de servicio, utilizando el repositorio correspondiente para interactuar con la base de datos.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 * @see TareaService
 * @see TareaRepository
 */
@Service
public class TareaServiceImpl implements TareaService {

    /**
     * Repositorio para operaciones de persistencia de tareas.
     */
    @Autowired
    private TareaRepository tareaRepository;

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public Tarea crearTarea(Tarea tarea) {
        return tareaRepository.save(tarea);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerTodasLasTareas() {
        return tareaRepository.findAll();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Tarea> obtenerTareaPorId(Long id) {
        return tareaRepository.findById(id);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public Tarea actualizarTarea(Long id, Tarea tareaDetails) {
        Tarea tarea = tareaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Tarea no encontrada con id: " + id));

        tarea.setTitulo(tareaDetails.getTitulo());
        tarea.setDescripcion(tareaDetails.getDescripcion());
        tarea.setFechaLimite(tareaDetails.getFechaLimite());
        tarea.setEstado(tareaDetails.getEstado());
        tarea.setPrioridad(tareaDetails.getPrioridad());
        tarea.setAsignado(tareaDetails.getAsignado());
        tarea.setComentarios(tareaDetails.getComentarios());
        tarea.setEsReunion(tareaDetails.isEsReunion());
        tarea.setUbicacion(tareaDetails.getUbicacion());

        return tareaRepository.save(tarea);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void eliminarTarea(Long id) {
        tareaRepository.deleteById(id);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public Tarea cambiarEstadoTarea(Long id, EstadoTarea nuevoEstado) {
        Tarea tarea = tareaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Tarea no encontrada con id: " + id));

        tarea.setEstado(nuevoEstado);
        return tareaRepository.save(tarea);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerTareasPorUsuarioAsignado(Long usuarioId) {
        return tareaRepository.findByAsignadoId(usuarioId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerTareasPorUsuarioCreador(Long usuarioId) {
        return tareaRepository.findByCreadorId(usuarioId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerTareasPendientesPorUsuario(Long usuarioId) {
        return tareaRepository.findByAsignadoIdAndEstado(usuarioId, EstadoTarea.PENDIENTE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerTareasProximasAVencer() {
        LocalDate fechaLimite = LocalDate.now().plusDays(7);
        return tareaRepository.findByFechaLimiteLessThanEqual(fechaLimite);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerReuniones() {
        return tareaRepository.findByEsReunionTrue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Tarea> obtenerReunionesPorUsuario(Long usuarioId) {
        return tareaRepository.findByAsignadoIdAndEsReunionTrue(usuarioId);
    }
}
