package com.login.guzpasen.services;

import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.models.Usuario;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Servicio que define las operaciones disponibles para la gestión de usuarios.
 * <p>
 * Esta interfaz proporciona métodos para crear, leer, actualizar y eliminar usuarios (CRUD),
 * así como para gestionar la asignación de módulos a los usuarios.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
public interface UsuarioService {
    /**
     * Crea un nuevo usuario en el sistema.
     *
     * @param usuario El objeto Usuario con la información a registrar
     * @return El usuario creado, incluyendo su ID generado
     */
    Usuario createUsuario(Usuario usuario);

    /**
     * Obtiene la lista de todos los usuarios registrados en el sistema.
     *
     * @return Lista de todos los usuarios
     */
    List<Usuario> getAllUsuarios();

    /**
     * Busca un usuario por su identificador único.
     *
     * @param id El ID del usuario a buscar
     * @return Un Optional que contiene el usuario si existe, o vacío si no se encuentra
     */
    Optional<Usuario> getUsuarioById(Long id);

    /**
     * Busca un usuario por su dirección de correo electrónico.
     *
     * @param email El email del usuario a buscar
     * @return Un Optional que contiene el usuario si existe, o vacío si no se encuentra
     */
    Optional<Usuario> getUsuarioByEmail(String email);

    /**
     * Actualiza la información de un usuario existente.
     *
     * @param id El ID del usuario a actualizar
     * @param usuarioDetails Objeto Usuario con los nuevos datos
     * @return El usuario actualizado
     * @throws jakarta.persistence.EntityNotFoundException si el usuario no existe
     */
    Usuario updateUsuario(Long id, Usuario usuarioDetails);

    /**
     * Elimina un usuario del sistema por su identificador.
     *
     * @param id El ID del usuario a eliminar
     */
    void deleteUsuario(Long id);

    /**
     * Obtiene el conjunto de módulos asignados a un usuario específico.
     *
     * @param usuarioId El ID del usuario
     * @return Conjunto de módulos asignados al usuario
     * @throws jakarta.persistence.EntityNotFoundException si el usuario no existe
     */
    Set<Modulo> getModulosByUsuario(Long usuarioId);

    /**
     * Asigna un módulo a un usuario.
     *
     * @param usuarioId El ID del usuario
     * @param moduloId El ID del módulo a asignar
     * @return El usuario actualizado con el nuevo módulo asignado
     * @throws jakarta.persistence.EntityNotFoundException si el usuario o módulo no existen
     */
    Usuario addModuloToUsuario(Long usuarioId, Long moduloId);

    @Transactional
    Usuario removeModuloFromUsuario(Long usuarioId, Long moduloId);

    /**
     * Elimina la asignación de un módulo a un usuario.
     *
     * @param usuarioId El ID del usuario
     * @param moduloId El ID del módulo a desasignar
     * @return El usuario actualizado sin el módulo
     * @throws jakarta.persistence.EntityNotFoundException si el usuario o módulo no existen
     */
}
