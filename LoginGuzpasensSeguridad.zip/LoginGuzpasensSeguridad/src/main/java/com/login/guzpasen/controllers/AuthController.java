package com.login.guzpasen.controllers;

import com.login.guzpasen.models.Rol;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credenciales) {
        String email = credenciales.get("email");
        String password = credenciales.get("password");

        return usuarioService.getUsuarioByEmail(email)
                .filter(usuario -> usuario.getPassword().equals(password) && usuario.isActivo())
                .map(usuario -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("id", usuario.getId());
                    response.put("nombre", usuario.getNombre());
                    response.put("apellidos", usuario.getApellidos());
                    response.put("email", usuario.getEmail());
                    response.put("rol", usuario.getRol());
                    response.put("activo", usuario.isActivo());
                    return ResponseEntity.ok(response);
                })
                .orElse(ResponseEntity.status(401).body(Map.of("mensaje", "Credenciales inválidas")));
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registro(@RequestBody Usuario usuario) {
        // Verificar si el email ya existe
        if (usuarioService.getUsuarioByEmail(usuario.getEmail()).isPresent()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("mensaje", "El email ya está registrado"));
        }

        // Por defecto, asignar rol PROFESOR si no se especifica
        if (usuario.getRol() == null) {
            usuario.setRol(Rol.PROFESOR);
        }

        // Guardar el nuevo usuario
        Usuario nuevoUsuario = usuarioService.createUsuario(usuario);

        // Preparar respuesta sin incluir la contraseña
        Map<String, Object> response = new HashMap<>();
        response.put("id", nuevoUsuario.getId());
        response.put("nombre", nuevoUsuario.getNombre());
        response.put("apellidos", nuevoUsuario.getApellidos());
        response.put("email", nuevoUsuario.getEmail());
        response.put("rol", nuevoUsuario.getRol());
        response.put("activo", nuevoUsuario.isActivo());

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/perfil")
    public ResponseEntity<?> obtenerPerfil(@RequestParam String email) {
        return usuarioService.getUsuarioByEmail(email)
                .map(usuario -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("id", usuario.getId());
                    response.put("nombre", usuario.getNombre());
                    response.put("apellidos", usuario.getApellidos());
                    response.put("email", usuario.getEmail());
                    response.put("rol", usuario.getRol());
                    response.put("activo", usuario.isActivo());
                    return ResponseEntity.ok(response);
                })
                .orElse(ResponseEntity.status(404).body(Map.of("mensaje", "Usuario no encontrado")));
    }
}
