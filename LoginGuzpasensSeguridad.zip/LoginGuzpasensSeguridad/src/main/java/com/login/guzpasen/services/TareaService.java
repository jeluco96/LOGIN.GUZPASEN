package com.login.guzpasen.services;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Servicio que define las operaciones disponibles para la gestión de tareas.
 * <p>
 * Esta interfaz proporciona métodos para crear, leer, actualizar y eliminar tareas (CRUD),
 * así como para buscar tareas según diversos criterios.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
public interface TareaService {

    /**
     * Crea una nueva tarea en el sistema.
     *
     * @param tarea La tarea a crear
     * @return La tarea creada con su ID generado
     */
    Tarea crearTarea(Tarea tarea);

    /**
     * Obtiene todas las tareas registradas en el sistema.
     *
     * @return Lista de todas las tareas
     */
    List<Tarea> obtenerTodasLasTareas();

    /**
     * Busca una tarea por su ID.
     *
     * @param id ID de la tarea a buscar
     * @return Optional con la tarea si existe, vacío en caso contrario
     */
    Optional<Tarea> obtenerTareaPorId(Long id);

    /**
     * Actualiza una tarea existente.
     *
     * @param id ID de la tarea a actualizar
     * @param tarea Datos actualizados de la tarea
     * @return La tarea actualizada
     * @throws jakarta.persistence.EntityNotFoundException si la tarea no existe
     */
    Tarea actualizarTarea(Long id, Tarea tarea);

    /**
     * Elimina una tarea del sistema.
     *
     * @param id ID de la tarea a eliminar
     */
    void eliminarTarea(Long id);

    /**
     * Cambia el estado de una tarea.
     *
     * @param id ID de la tarea
     * @param nuevoEstado Nuevo estado a asignar
     * @return La tarea actualizada
     * @throws jakarta.persistence.EntityNotFoundException si la tarea no existe
     */
    Tarea cambiarEstadoTarea(Long id, EstadoTarea nuevoEstado);

    /**
     * Obtiene las tareas asignadas a un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas asignadas al usuario
     */
    List<Tarea> obtenerTareasPorUsuarioAsignado(Long usuarioId);

    /**
     * Obtiene las tareas creadas por un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas creadas por el usuario
     */
    List<Tarea> obtenerTareasPorUsuarioCreador(Long usuarioId);

    /**
     * Obtiene las tareas que están pendientes para un usuario.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas pendientes del usuario
     */
    List<Tarea> obtenerTareasPendientesPorUsuario(Long usuarioId);

    /**
     * Obtiene las tareas con fecha límite próxima (dentro de una semana).
     *
     * @return Lista de tareas con vencimiento próximo
     */
    List<Tarea> obtenerTareasProximasAVencer();

    /**
     * Obtiene las reuniones programadas.
     *
     * @return Lista de tareas que son reuniones
     */
    List<Tarea> obtenerReuniones();

    /**
     * Obtiene las reuniones asignadas a un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de reuniones asignadas al usuario
     */
    List<Tarea> obtenerReunionesPorUsuario(Long usuarioId);
}
