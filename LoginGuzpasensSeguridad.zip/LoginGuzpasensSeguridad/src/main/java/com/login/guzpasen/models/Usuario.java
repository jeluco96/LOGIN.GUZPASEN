package com.login.guzpasen.models;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;

/**
 * Entidad que representa a un usuario del sistema.
 * <p>
 * Esta clase contiene la información básica de un usuario, como sus datos personales,
 * credenciales de acceso, estado y rol dentro del sistema. Además, mantiene la relación
 * con los módulos a los que tiene acceso el usuario.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
@Entity
@Data
public class Usuario {
    /** 
     * Identificador único del usuario. Se genera automáticamente.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nombre del usuario.
     */
    private String nombre;

    /**
     * Apellidos del usuario.
     */
    private String apellidos;

    /**
     * Correo electrónico del usuario. Debe ser único en el sistema.
     */
    @Column(unique = true)
    private String email;

    /**
     * Contraseña del usuario. En un entorno de producción, esta contraseña
     * debería almacenarse encriptada.
     */
    private String password;

    /**
     * Indica si el usuario está activo en el sistema.
     * Por defecto, un usuario se crea como activo.
     */
    private boolean activo = true;

    /**
     * Rol asignado al usuario dentro del sistema.
     * @see Rol
     */
    @Enumerated(EnumType.STRING)
    private Rol rol;

    /**
     * Conjunto de módulos a los que el usuario tiene acceso.
     * La relación se materializa en la tabla intermedia 'usuario_modulo'.
     */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "usuario_modulo",
        joinColumns = @JoinColumn(name = "usuario_id"),
        inverseJoinColumns = @JoinColumn(name = "modulo_id")
    )
    private Set<Modulo> modulos;
}
