package com.login.guzpasen.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuración global para CORS (Cross-Origin Resource Sharing).
 * <p>
 * Esta clase permite configurar qué orígenes, métodos HTTP y cabeceras
 * están permitidos para las solicitudes desde dominios externos.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Configura las políticas CORS para todos los endpoints de la API.
     * 
     * @param registry El registro de CORS donde se definen las configuraciones
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*") // En producción, limitar a dominios específicos
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                .allowedHeaders("*")
                .maxAge(3600); // Tiempo en segundos para cachear la configuración CORS
    }
}
