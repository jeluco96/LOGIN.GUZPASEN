package com.login.guzpasen.services;
import com.login.guzpasen.models.Modulo;

import java.util.List;

public interface ModuloService {
    List<Modulo> getAllModulos();
    Modulo createModulo(Modulo modulo);
    void deleteModulo(Long id);
}
