package com.login.guzpasen.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import lombok.Data;

/**
 * Entidad que representa un módulo o funcionalidad del sistema.
 * <p>
 * Esta clase define los módulos que pueden ser asignados a los usuarios,
 * permitiendo gestionar el acceso a diferentes partes de la aplicación
 * en función de los permisos del usuario.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
@Entity
@Data
public class Modulo {
    /**
     * Identificador único del módulo. Se genera automáticamente.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nombre del módulo.
     */
    private String nombre;

    /**
     * Descripción detallada del módulo y sus funcionalidades.
     * Permite hasta 1000 caracteres.
     */
    @Column(length = 1000)
    private String descripcion;

    /**
     * Icono representativo del módulo. Generalmente se almacena como
     * una clase CSS o ruta a un archivo de imagen.
     */
    private String icono;

    /**
     * URL o ruta de acceso al módulo dentro de la aplicación.
     * Esta URL se utiliza para navegar hacia el módulo desde el menú o dashboard.
     */
}
