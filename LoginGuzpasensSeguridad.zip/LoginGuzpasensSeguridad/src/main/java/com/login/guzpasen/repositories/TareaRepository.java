package com.login.guzpasen.repositories;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repositorio para operaciones de persistencia de la entidad Tarea.
 * <p>
 * Proporciona métodos para buscar tareas según diversos criterios como estado,
 * usuario asignado, fecha límite, etc.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@Repository
public interface TareaRepository extends JpaRepository<Tarea, Long> {

    /**
     * Busca tareas por el ID del usuario asignado.
     *
     * @param asignadoId ID del usuario asignado
     * @return Lista de tareas asignadas al usuario
     */
    List<Tarea> findByAsignadoId(Long asignadoId);

    /**
     * Busca tareas por el ID del usuario que las creó.
     *
     * @param creadorId ID del usuario creador
     * @return Lista de tareas creadas por el usuario
     */
    List<Tarea> findByCreadorId(Long creadorId);

    /**
     * Busca tareas por estado.
     *
     * @param estado Estado de las tareas a buscar
     * @return Lista de tareas en el estado especificado
     */
    List<Tarea> findByEstado(EstadoTarea estado);

    /**
     * Busca tareas por el ID del usuario asignado y el estado.
     *
     * @param asignadoId ID del usuario asignado
     * @param estado Estado de las tareas a buscar
     * @return Lista de tareas que cumplen ambos criterios
     */
    List<Tarea> findByAsignadoIdAndEstado(Long asignadoId, EstadoTarea estado);

    /**
     * Busca tareas con fecha límite anterior o igual a la fecha especificada.
     *
     * @param fecha Fecha de referencia
     * @return Lista de tareas con fecha límite antes o igual a la fecha
     */
    List<Tarea> findByFechaLimiteLessThanEqual(LocalDate fecha);

    /**
     * Busca tareas que son reuniones.
     *
     * @return Lista de tareas marcadas como reuniones
     */
    List<Tarea> findByEsReunionTrue();

    /**
     * Busca tareas por usuario asignado que son reuniones.
     *
     * @param asignadoId ID del usuario asignado
     * @return Lista de reuniones asignadas al usuario
     */
    List<Tarea> findByAsignadoIdAndEsReunionTrue(Long asignadoId);
}
