package com.login.guzpasen.controllers;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;
import com.login.guzpasen.services.TareaService;
import com.login.guzpasen.services.UsuarioService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST que expone endpoints para la gestión de tareas.
 * <p>
 * Proporciona operaciones CRUD para tareas, así como endpoints específicos
 * para buscar tareas según diversos criterios y cambiar estados.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@RestController
@RequestMapping("/api/tareas")
public class TareaController {

    @Autowired
    private TareaService tareaService;

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Crea una nueva tarea.
     *
     * @param tarea Datos de la tarea a crear
     * @return La tarea creada con su ID generado
     */
    @PostMapping
    public ResponseEntity<Tarea> crearTarea(@RequestBody Tarea tarea) {
        Tarea nuevaTarea = tareaService.crearTarea(tarea);
        return new ResponseEntity<>(nuevaTarea, HttpStatus.CREATED);
    }

    /**
     * Obtiene todas las tareas del sistema.
     *
     * @return Lista de todas las tareas
     */
    @GetMapping
    public List<Tarea> obtenerTodasLasTareas() {
        return tareaService.obtenerTodasLasTareas();
    }

    /**
     * Obtiene una tarea específica por su ID.
     *
     * @param id ID de la tarea a buscar
     * @return La tarea si existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtenerTareaPorId(@PathVariable Long id) {
        return tareaService.obtenerTareaPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Actualiza una tarea existente.
     *
     * @param id ID de la tarea a actualizar
     * @param tarea Datos actualizados de la tarea
     * @return La tarea actualizada
     */
    @PutMapping("/{id}")
    public ResponseEntity<Tarea> actualizarTarea(@PathVariable Long id, @RequestBody Tarea tarea) {
        try {
            Tarea tareaActualizada = tareaService.actualizarTarea(id, tarea);
            return ResponseEntity.ok(tareaActualizada);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Elimina una tarea del sistema.
     *
     * @param id ID de la tarea a eliminar
     * @return Respuesta sin contenido si se eliminó correctamente
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarTarea(@PathVariable Long id) {
        tareaService.eliminarTarea(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Cambia el estado de una tarea.
     *
     * @param id ID de la tarea
     * @param body Mapa con el nuevo estado
     * @return La tarea con el estado actualizado
     */
    @PatchMapping("/{id}/estado")
    public ResponseEntity<Tarea> cambiarEstadoTarea(@PathVariable Long id, @RequestBody Map<String, String> body) {
        try {
            String nuevoEstadoStr = body.get("estado");
            if (nuevoEstadoStr == null) {
                return ResponseEntity.badRequest().build();
            }

            EstadoTarea nuevoEstado = EstadoTarea.valueOf(nuevoEstadoStr);
            Tarea tareaActualizada = tareaService.cambiarEstadoTarea(id, nuevoEstado);
            return ResponseEntity.ok(tareaActualizada);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Obtiene las tareas asignadas a un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas asignadas al usuario
     */
    @GetMapping("/usuario/{usuarioId}/asignadas")
    public ResponseEntity<List<Tarea>> obtenerTareasPorUsuarioAsignado(@PathVariable Long usuarioId) {
        if (!usuarioService.getUsuarioById(usuarioId).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(tareaService.obtenerTareasPorUsuarioAsignado(usuarioId));
    }

    /**
     * Obtiene las tareas creadas por un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas creadas por el usuario
     */
    @GetMapping("/usuario/{usuarioId}/creadas")
    public ResponseEntity<List<Tarea>> obtenerTareasPorUsuarioCreador(@PathVariable Long usuarioId) {
        if (!usuarioService.getUsuarioById(usuarioId).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(tareaService.obtenerTareasPorUsuarioCreador(usuarioId));
    }

    /**
     * Obtiene las tareas pendientes de un usuario.
     *
     * @param usuarioId ID del usuario
     * @return Lista de tareas pendientes del usuario
     */
    @GetMapping("/usuario/{usuarioId}/pendientes")
    public ResponseEntity<List<Tarea>> obtenerTareasPendientesPorUsuario(@PathVariable Long usuarioId) {
        if (!usuarioService.getUsuarioById(usuarioId).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(tareaService.obtenerTareasPendientesPorUsuario(usuarioId));
    }

    /**
     * Obtiene las tareas próximas a vencer (en la próxima semana).
     *
     * @return Lista de tareas con vencimiento próximo
     */
    @GetMapping("/proximas-a-vencer")
    public List<Tarea> obtenerTareasProximasAVencer() {
        return tareaService.obtenerTareasProximasAVencer();
    }

    /**
     * Obtiene todas las reuniones programadas.
     *
     * @return Lista de reuniones
     */
    @GetMapping("/reuniones")
    public List<Tarea> obtenerReuniones() {
        return tareaService.obtenerReuniones();
    }

    /**
     * Obtiene las reuniones asignadas a un usuario específico.
     *
     * @param usuarioId ID del usuario
     * @return Lista de reuniones del usuario
     */
    @GetMapping("/usuario/{usuarioId}/reuniones")
    public ResponseEntity<List<Tarea>> obtenerReunionesPorUsuario(@PathVariable Long usuarioId) {
        if (!usuarioService.getUsuarioById(usuarioId).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(tareaService.obtenerReunionesPorUsuario(usuarioId));
    }
}
