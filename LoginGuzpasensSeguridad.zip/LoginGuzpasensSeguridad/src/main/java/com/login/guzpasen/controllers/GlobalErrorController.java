package com.login.guzpasen.controllers;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controlador global para manejar y personalizar las respuestas de error.
 * <p>
 * Esta clase intercepta los errores de la aplicación y muestra páginas
 * personalizadas según el tipo de error ocurrido.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-09
 */
@Controller
public class GlobalErrorController implements ErrorController {

    /**
     * Maneja las solicitudes a la ruta /error y muestra páginas personalizadas
     * según el código de estado HTTP del error.
     *
     * @param request La solicitud HTTP que generó el error
     * @param model El modelo para la vista
     * @return La plantilla de error correspondiente
     */
    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String errorPage = "error/error";
        String errorMessage = "Ha ocurrido un error inesperado";

        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());
            model.addAttribute("codigo", statusCode);

            if (statusCode == HttpStatus.NOT_FOUND.value()) {
                errorPage = "error/404";
                errorMessage = "La página solicitada no ha sido encontrada";
            } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                errorPage = "error/500";
                errorMessage = "Error interno del servidor";
            } else if (statusCode == HttpStatus.FORBIDDEN.value()) {
                errorPage = "error/403";
                errorMessage = "No tiene permisos para acceder a este recurso";
            } else if (statusCode == HttpStatus.BAD_REQUEST.value()) {
                errorPage = "error/400";
                errorMessage = "Solicitud incorrecta";
            }
        }

        model.addAttribute("mensaje", errorMessage);
        return errorPage;
    }
}
