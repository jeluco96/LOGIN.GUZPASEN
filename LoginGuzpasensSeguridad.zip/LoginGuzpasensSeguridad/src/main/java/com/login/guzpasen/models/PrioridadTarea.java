package com.login.guzpasen.models;

/**
 * Enumeración que define los niveles de prioridad para las tareas.
 * <p>
 * La prioridad ayuda a determinar qué tareas deben ser atendidas primero
 * y facilita la organización del trabajo.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
public enum PrioridadTarea {
    /**
     * Prioridad baja. Tareas que pueden esperar o no son urgentes.
     */
    BAJA,

    /**
     * Prioridad media. Tareas con importancia moderada.
     */
    MEDIA,

    /**
     * Prioridad alta. Tareas importantes que requieren atención pronta.
     */
    ALTA,

    /**
     * Prioridad crítica. Tareas que requieren atención inmediata.
     */
    CRITICA
}
