package com.login.guzpasen.controllers;

import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.repositories.ModuloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST para la gestión de módulos.
 * <p>
 * Esta clase proporciona endpoints para realizar operaciones CRUD sobre los módulos
 * del sistema, permitiendo crear, listar, actualizar y eliminar módulos.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
@RestController
@RequestMapping("/api/modulos")
public class ModuloController {

    @Autowired
    private ModuloRepository moduloRepository;

    /**
     * Crea un nuevo módulo en el sistema.
     *
     * @param modulo El objeto Modulo con la información a registrar
     * @return El módulo creado con su ID generado
     */
    @PostMapping
    public ResponseEntity<Modulo> crearModulo(@RequestBody Modulo modulo) {
        Modulo nuevoModulo = moduloRepository.save(modulo);
        return new ResponseEntity<>(nuevoModulo, HttpStatus.CREATED);
    }

    /**
     * Obtiene la lista de todos los módulos disponibles en el sistema.
     *
     * @return Lista de todos los módulos
     */
    @GetMapping
    public List<Modulo> obtenerTodosModulos() {
        return moduloRepository.findAll();
    }

    /**
     * Busca un módulo específico por su ID.
     *
     * @param id El ID del módulo a buscar
     * @return El módulo si se encuentra, o un error 404 si no existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<Modulo> obtenerModuloPorId(@PathVariable Long id) {
        return moduloRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Actualiza la información de un módulo existente.
     *
     * @param id El ID del módulo a actualizar
     * @param moduloDetails Objeto Modulo con los nuevos datos
     * @return El módulo actualizado, o un error 404 si no existe
     */
    @PutMapping("/{id}")
    public ResponseEntity<Modulo> actualizarModulo(@PathVariable Long id, @RequestBody Modulo moduloDetails) {
        return moduloRepository.findById(id)
                .map(modulo -> {
                    modulo.setNombre(moduloDetails.getNombre());
                    modulo.setDescripcion(moduloDetails.getDescripcion());
                    modulo.setIcono(moduloDetails.getIcono());
                    return ResponseEntity.ok(moduloRepository.save(modulo));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Elimina un módulo del sistema.
     *
     * @param id El ID del módulo a eliminar
     * @return Respuesta vacía con código 204 si se eliminó correctamente, o 404 si no existe
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarModulo(@PathVariable Long id) {
        return moduloRepository.findById(id)
                .map(modulo -> {
                    moduloRepository.delete(modulo);
                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}

