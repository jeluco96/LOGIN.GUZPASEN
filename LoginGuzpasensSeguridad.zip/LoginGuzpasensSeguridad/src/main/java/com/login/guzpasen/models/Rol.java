package com.login.guzpasen.models;

/**
 * Enumeración que define los roles disponibles en el sistema.
 * <p>
 * Estos roles determinan los niveles de acceso y permisos
 * que tendrán los usuarios dentro de la aplicación.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2023-06-09
 */
public enum Rol {
    /**
     * Rol de profesor. Acceso a módulos educativos y gestión académica.
     */
    PROFESOR,

    /**
     * Rol de administrador. Acceso completo al sistema, incluida la gestión de usuarios y módulos.
     */
    ADMINISTRADOR,

    /**
     * Rol de técnico. Acceso a funcionalidades de soporte y mantenimiento.
     */
    TECNICO
}
