package com.login.guzpasen.models;

/**
 * Enumeración que define los posibles estados de una tarea.
 * <p>
 * Estos estados permiten hacer seguimiento del progreso de las tareas
 * a lo largo de su ciclo de vida.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
public enum EstadoTarea {
    /**
     * Tarea que aún no ha sido iniciada.
     */
    PENDIENTE,

    /**
     * Tarea que se encuentra en proceso de realización.
     */
    EN_PROGRESO,

    /**
     * Tarea que ha sido completada.
     */
    COMPLETADA,

    /**
     * Tarea que ha sido cancelada o descartada.
     */
    CANCELADA,

    /**
     * Tarea que se encuentra retrasada respecto a su fecha límite.
     */
    RETRASADA
}
