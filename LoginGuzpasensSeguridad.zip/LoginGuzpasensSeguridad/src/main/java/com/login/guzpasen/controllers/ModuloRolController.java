package com.login.guzpasen.controllers;

import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.models.Rol;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.services.ModuloService;
import com.login.guzpasen.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/roles")
public class ModuloRolController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ModuloService moduloService;

    @GetMapping("/modulos/{rol}")
    public ResponseEntity<List<Modulo>> getModulosByRol(@PathVariable Rol rol) {
        // Obtenemos todos los usuarios con ese rol
        List<Usuario> usuariosConRol = usuarioService.getAllUsuarios().stream()
                .filter(u -> u.getRol() == rol)
                .collect(Collectors.toList());

        // Recopilamos todos los módulos asociados a esos usuarios
        Set<Modulo> modulosDelRol = usuariosConRol.stream()
                .flatMap(u -> u.getModulos().stream())
                .collect(Collectors.toSet());

        return ResponseEntity.ok(modulosDelRol.stream().toList());
    }

    @PostMapping("/asignarModuloARol")
    public ResponseEntity<?> asignarModuloARol(@RequestBody Map<String, Object> payload) {
        try {
            Rol rol = Rol.valueOf(payload.get("rol").toString());
            Long moduloId = Long.parseLong(payload.get("moduloId").toString());

            // Obtenemos todos los usuarios con ese rol
            List<Usuario> usuariosConRol = usuarioService.getAllUsuarios().stream()
                    .filter(u -> u.getRol() == rol)
                    .collect(Collectors.toList());

            // Asignamos el módulo a todos los usuarios con ese rol
            for (Usuario usuario : usuariosConRol) {
                usuarioService.addModuloToUsuario(usuario.getId(), moduloId);
            }

            return ResponseEntity.ok().body(Map.of(
                    "mensaje", "Módulo asignado a todos los usuarios con rol " + rol
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "Error al asignar módulo: " + e.getMessage()
            ));
        }
    }

    @PostMapping("/eliminarModuloDeRol")
    public ResponseEntity<?> eliminarModuloDeRol(@RequestBody Map<String, Object> payload) {
        try {
            Rol rol = Rol.valueOf(payload.get("rol").toString());
            Long moduloId = Long.parseLong(payload.get("moduloId").toString());

            // Obtenemos todos los usuarios con ese rol
            List<Usuario> usuariosConRol = usuarioService.getAllUsuarios().stream()
                    .filter(u -> u.getRol() == rol)
                    .collect(Collectors.toList());

            // Eliminamos el módulo de todos los usuarios con ese rol
            for (Usuario usuario : usuariosConRol) {
                usuarioService.removeModuloFromUsuario(usuario.getId(), moduloId);
            }

            return ResponseEntity.ok().body(Map.of(
                    "mensaje", "Módulo eliminado de todos los usuarios con rol " + rol
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "Error al eliminar módulo: " + e.getMessage()
            ));
        }
    }

    @GetMapping("/validarAcceso")
    public ResponseEntity<?> validarAccesoAModulo(
            @RequestParam Long usuarioId, 
            @RequestParam Long moduloId) {
        try {
            Set<Modulo> modulosUsuario = usuarioService.getModulosByUsuario(usuarioId);
            boolean tieneAcceso = modulosUsuario.stream()
                    .anyMatch(m -> m.getId().equals(moduloId));

            return ResponseEntity.ok(Map.of(
                    "tieneAcceso", tieneAcceso
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "Error al validar acceso: " + e.getMessage()
            ));
        }
    }
}
