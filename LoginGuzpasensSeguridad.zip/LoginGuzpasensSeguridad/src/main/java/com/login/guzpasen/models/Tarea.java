package com.login.guzpasen.models;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entidad que representa una tarea en el sistema.
 * <p>
 * Esta clase contiene la información relacionada con tareas asignadas a los usuarios,
 * incluyendo su descripción, fecha límite, estado y usuario asignado.
 * </p>
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@Entity
@Data
public class Tarea {
    /**
     * Identificador único de la tarea. Se genera automáticamente.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Título descriptivo de la tarea.
     */
    private String titulo;

    /**
     * Descripción detallada de la tarea.
     */
    @Column(length = 2000)
    private String descripcion;

    /**
     * Fecha de creación de la tarea.
     */
    private LocalDateTime fechaCreacion = LocalDateTime.now();

    /**
     * Fecha límite para completar la tarea.
     */
    private LocalDate fechaLimite;

    /**
     * Estado actual de la tarea.
     */
    @Enumerated(EnumType.STRING)
    private EstadoTarea estado = EstadoTarea.PENDIENTE;

    /**
     * Prioridad de la tarea.
     */
    @Enumerated(EnumType.STRING)
    private PrioridadTarea prioridad = PrioridadTarea.MEDIA;

    /**
     * Usuario que creó la tarea.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "creador_id")
    private Usuario creador;

    /**
     * Usuario asignado para completar la tarea.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "asignado_id")
    private Usuario asignado;

    /**
     * Comentarios o notas adicionales sobre la tarea.
     */
    @Column(length = 1000)
    private String comentarios;

    /**
     * Indica si la tarea es una reunión programada.
     */
    private boolean esReunion = false;

    /**
     * Ubicación de la reunión (si aplica).
     */
    private String ubicacion;
}
