// Variables globales
let currentTaskId = null;
let currentTasks = [];
let currentUser = null;
let allUsers = [];

// Inicialización al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    // Verificar sesión de usuario
    const usuarioData = JSON.parse(sessionStorage.getItem('usuario') || '{}');
    if (!usuarioData.id) {
        window.location.href = '/';
        return;
    }

    // Guardar datos del usuario actual
    currentUser = usuarioData;
    console.log('Usuario actual:', currentUser);
    document.getElementById('nombreUsuario').textContent = usuarioData.nombre + ' ' + usuarioData.apellidos;

    // Configurar eventos de navegación
    setupNavigation();

    // Cargar usuarios para los selectores
    loadUsers();

    // Cargar tareas iniciales
    loadTasks();

    // Configurar event listeners de filtros
    setupFilters();

    // Configurar event listeners de modales y botones
    setupModalListeners();
});

// Configurar navegación
function setupNavigation() {
    document.getElementById('btnHome').addEventListener('click', function() {
        if (currentUser.rol === 'ADMINISTRADOR') {
            window.location.href = '/admin/dashboard.html';
        } else {
            window.location.href = '/usuario/dashboard.html';
        }
    });

    document.getElementById('btnCerrarSesion').addEventListener('click', function() {
        sessionStorage.removeItem('usuario');
        window.location.href = '/';
    });
}

// Cargar usuarios para los selectores
function loadUsers() {
    fetch('/api/usuarios')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar usuarios: ' + response.status);
            }
            return response.json();
        })
        .then(users => {
            allUsers = users;
            const selectAssignee = document.getElementById('taskAssignee');
            const selectParticipants = document.getElementById('reunionParticipants');

            selectAssignee.innerHTML = '';
            selectParticipants.innerHTML = '';

            // Añadir opción para asignar a uno mismo
            const selfOption = document.createElement('option');
            selfOption.value = currentUser.id;
            selfOption.textContent = `${currentUser.nombre} ${currentUser.apellidos} (yo)`;
            selfOption.selected = true;
            selectAssignee.appendChild(selfOption);

            // Añadir el resto de usuarios
            users.forEach(user => {
                if (user.id !== currentUser.id && user.activo) {
                    // Para el selector de asignación individual
                    const option = document.createElement('option');
                    option.value = user.id;
                    option.textContent = `${user.nombre} ${user.apellidos}`;
                    selectAssignee.appendChild(option);

                    // Para el selector múltiple de participantes
                    const optionParticipant = document.createElement('option');
                    optionParticipant.value = user.id;
                    optionParticipant.textContent = `${user.nombre} ${user.apellidos}`;
                    selectParticipants.appendChild(optionParticipant);
                }
            });
        })
        .catch(error => {
            console.error('Error al cargar usuarios:', error);
            alert('No se pudieron cargar los usuarios. Por favor, recarga la página.');
        });
}

// Cargar tareas
function loadTasks(filterPriority = '', filterType = '') {
    console.log('Cargando tareas...');

    // Determinar endpoint para las tareas
    const endpoint = '/api/tareas';

    fetch(endpoint)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar tareas: ' + response.status);
            }
            return response.json();
        })
        .then(tasks => {
            console.log('Tareas recibidas del servidor:', tasks);

            // Si no es administrador, filtrar para mostrar solo las tareas relevantes
            if (currentUser.rol !== 'ADMINISTRADOR') {
                tasks = tasks.filter(task => 
                    (task.asignado && task.asignado.id === currentUser.id) || 
                    (task.creador && task.creador.id === currentUser.id)
                );
            }

            currentTasks = tasks;
            console.log('Tareas filtradas para el usuario actual:', currentTasks);

            // Aplicar filtros adicionales si existen
            let filteredTasks = [...currentTasks];
            if (filterPriority) {
                filteredTasks = filteredTasks.filter(task => task.prioridad === filterPriority);
            }
            if (filterType === 'tarea') {
                filteredTasks = filteredTasks.filter(task => !task.esReunion);
            } else if (filterType === 'reunion') {
                filteredTasks = filteredTasks.filter(task => task.esReunion);
            }

            // Limpiar columnas
            document.getElementById('columnPendiente').innerHTML = '';
            document.getElementById('columnEnProgreso').innerHTML = '';
            document.getElementById('columnCompletada').innerHTML = '';
            document.getElementById('columnRetrasada').innerHTML = '';

            // Distribuir tareas por columnas según estado
            filteredTasks.forEach(task => {
                if (task.estado === 'CANCELADA') return; // No mostrar tareas canceladas

                // Mapear el estado a la columna correspondiente
                let columnId;
                switch(task.estado) {
                    case 'PENDIENTE':
                        columnId = 'columnPendiente';
                        break;
                    case 'EN_PROGRESO':
                        columnId = 'columnEnProgreso';
                        break;
                    case 'COMPLETADA':
                        columnId = 'columnCompletada';
                        break;
                    case 'RETRASADA':
                        columnId = 'columnRetrasada';
                        break;
                    default:
                        columnId = 'columnPendiente'; // Por defecto, mostrar en pendientes
                }

                const column = document.getElementById(columnId);
                if (column) {
                    column.appendChild(createTaskCard(task));
                }
            });

            console.log('Tareas distribuidas en columnas. Total mostradas:', filteredTasks.length);

            // Si no hay tareas, mostrar un mensaje
            if (filteredTasks.length === 0) {
                document.querySelectorAll('.status-column').forEach(column => {
                    if (column.children.length === 0) {
                        const emptyMsg = document.createElement('div');
                        emptyMsg.className = 'text-center text-muted py-3';
                        emptyMsg.innerHTML = '<i class="bi bi-info-circle"></i> No hay tareas en esta categoría';
                        column.appendChild(emptyMsg);
                    }
                });
            }
        })
        .catch(error => {
            console.error('Error al cargar tareas:', error);
            alert('No se pudieron cargar las tareas. Por favor, recarga la página.');
        });
}

// Cargar tareas próximas a vencer
function loadUpcomingTasks() {
    fetch('/api/tareas/proximas-a-vencer')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar tareas próximas: ' + response.status);
            }
            return response.json();
        })
        .then(tasks => {
            // Filtrar solo para las tareas asignadas al usuario actual si no es admin
            let filteredTasks = tasks;
            if (currentUser.rol !== 'ADMINISTRADOR') {
                filteredTasks = tasks.filter(task => task.asignado && task.asignado.id === currentUser.id);
            }

            currentTasks = filteredTasks;

            // Limpiar columnas
            document.getElementById('columnPendiente').innerHTML = '';
            document.getElementById('columnEnProgreso').innerHTML = '';
            document.getElementById('columnCompletada').innerHTML = '';
            document.getElementById('columnRetrasada').innerHTML = '';

            // Distribuir tareas por columnas según estado
            filteredTasks.forEach(task => {
                if (task.estado === 'CANCELADA') return; // No mostrar tareas canceladas

                // Determinar la columna correcta
                let columnId;
                switch(task.estado) {
                    case 'PENDIENTE':
                        columnId = 'columnPendiente';
                        break;
                    case 'EN_PROGRESO':
                        columnId = 'columnEnProgreso';
                        break;
                    case 'COMPLETADA':
                        columnId = 'columnCompletada';
                        break;
                    case 'RETRASADA':
                        columnId = 'columnRetrasada';
                        break;
                    default:
                        columnId = 'columnPendiente'; // Por defecto
                }

                const column = document.getElementById(columnId);
                if (column) {
                    column.appendChild(createTaskCard(task));
                }
            });

            // Si no hay tareas, mostrar mensaje
            if (filteredTasks.length === 0) {
                alert('No hay tareas próximas a vencer en los próximos 7 días.');
            }
        })
        .catch(error => {
            console.error('Error al cargar tareas próximas:', error);
            alert('No se pudieron cargar las tareas próximas a vencer. Por favor, intenta de nuevo.');
        });
}

// Crear tarjeta de tarea
function createTaskCard(task) {
    const card = document.createElement('div');
    card.className = `card task-card priority-${task.prioridad.toLowerCase()}`;
    card.dataset.id = task.id;

    // Calcular si la tarea está próxima a vencer
    let dateClass = '';
    let dateText = '';

    if (task.fechaLimite) {
        const now = new Date();
        const dueDate = new Date(task.fechaLimite);
        const diffDays = Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24));

        if (diffDays < 0) {
            dateClass = 'date-warning';
            dateText = `Vencida hace ${Math.abs(diffDays)} día(s)`;
        } else if (diffDays === 0) {
            dateClass = 'date-warning';
            dateText = 'Vence hoy';
        } else if (diffDays <= 3) {
            dateClass = 'date-warning';
            dateText = `Vence en ${diffDays} día(s)`;
        } else {
            dateText = `Vence el ${formatDate(task.fechaLimite)}`;
        }
    }

    // Nombre del asignado
    let assigneeName = 'Sin asignar';
    if (task.asignado) {
        assigneeName = `${task.asignado.nombre} ${task.asignado.apellidos}`;
        if (task.asignado.id === currentUser.id) {
            assigneeName += ' (yo)';
        }
    }

    card.innerHTML = `
        <div class="card-body">
            <div class="task-header">
                <h5 class="card-title">${task.titulo}</h5>
                <div class="task-actions">
                    <button class="btn btn-sm btn-outline-info btn-view" title="Ver detalles">
                        <i class="bi bi-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary btn-edit" title="Editar tarea">
                        <i class="bi bi-pencil"></i>
                    </button>
                </div>
            </div>
            <h6 class="card-subtitle mb-2 text-muted">${assigneeName}</h6>
            <p class="card-text">${task.descripcion.substring(0, 100)}${task.descripcion.length > 100 ? '...' : ''}</p>
            <div class="d-flex justify-content-between align-items-center">
                <span class="badge ${task.esReunion ? 'badge-reunion' : 'bg-secondary'}">
                    ${task.esReunion ? '<i class="bi bi-calendar-event"></i> Reunión' : 'Tarea'}
                </span>
                <span class="badge bg-${getPriorityBadgeColor(task.prioridad)}">${task.prioridad}</span>
            </div>
            <div class="date-highlight ${dateClass}">
                <i class="bi bi-calendar"></i> ${dateText}
            </div>
        </div>
    `;

    // Añadir event listeners
    card.querySelector('.btn-view').addEventListener('click', () => viewTaskDetails(task.id));
    card.querySelector('.btn-edit').addEventListener('click', () => editTask(task.id));

    return card;
}

// Configurar filtros
function setupFilters() {
    document.getElementById('filterPriority').addEventListener('change', function() {
        const priority = this.value;
        const type = document.getElementById('filterType').value;
        loadTasks(priority, type);
    });

    document.getElementById('filterType').addEventListener('change', function() {
        const type = this.value;
        const priority = document.getElementById('filterPriority').value;
        loadTasks(priority, type);
    });

    document.getElementById('btnProximasVencer').addEventListener('click', function() {
        loadUpcomingTasks();
        // Resetear los filtros
        document.getElementById('filterPriority').value = '';
        document.getElementById('filterType').value = '';
    });
}

// Configurar listeners para modales y botones
function setupModalListeners() {
    // Modal de tarea
    const taskModal = document.getElementById('taskModal');
    taskModal.addEventListener('show.bs.modal', function() {
        // Si es una nueva tarea, establecer la fecha límite por defecto a mañana
        if (!currentTaskId) {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            document.getElementById('taskDueDate').value = formatDateForInput(tomorrow);
        }
    });

    // Botón de guardar tarea
    document.getElementById('btnSaveTask').addEventListener('click', saveTask);

    // Modal de reunión
    const reunionModal = document.getElementById('reunionModal');
    reunionModal.addEventListener('show.bs.modal', function() {
        // Si es una nueva reunión, establecer la fecha por defecto a mañana
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        document.getElementById('reunionDate').value = formatDateForInput(tomorrow);
    });

    // Botón de guardar reunión
    document.getElementById('btnSaveReunion').addEventListener('click', saveReunion);

    // Modal de detalles
    document.getElementById('btnEditTask').addEventListener('click', function() {
        const taskId = currentTaskId;
        bootstrap.Modal.getInstance(document.getElementById('taskDetailsModal')).hide();
        setTimeout(() => {
            editTask(taskId);
        }, 500);
    });

    // Cambio de estado desde dropdown
    document.querySelectorAll('#statusDropdown .dropdown-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const newStatus = this.getAttribute('data-status');
            changeTaskStatus(currentTaskId, newStatus);
        });
    });
}

// Ver detalles de tarea
function viewTaskDetails(taskId) {
    currentTaskId = taskId;
    const task = currentTasks.find(t => t.id == taskId);

    if (!task) {
        console.error('No se encontró la tarea con ID:', taskId);
        alert('No se pudo encontrar la información de esta tarea.');
        return;
    }

    // Actualizar título del modal
    document.getElementById('detailsModalTitle').textContent = task.esReunion ? 'Detalles de la Reunión' : 'Detalles de la Tarea';

    // Llenar datos
    document.getElementById('detailsCreatedBy').textContent = task.creador ? `${task.creador.nombre} ${task.creador.apellidos}` : 'Sistema';
    document.getElementById('detailsCreationDate').textContent = formatDateTime(task.fechaCreacion);
    document.getElementById('detailsAssignee').textContent = task.asignado ? `${task.asignado.nombre} ${task.asignado.apellidos}` : 'Sin asignar';
    document.getElementById('detailsDueDate').textContent = formatDate(task.fechaLimite);
    document.getElementById('detailsDescription').textContent = task.descripcion;
    document.getElementById('detailsComments').textContent = task.comentarios || 'Sin comentarios';

    // Mostrar u ocultar sección de reunión
    const reunionSection = document.getElementById('reunionDetailsSection');
    if (task.esReunion) {
        reunionSection.classList.remove('d-none');
        document.getElementById('detailsLocation').textContent = task.ubicacion || 'No especificada';
        // Aquí se mostrarían los participantes si se implementa esa funcionalidad
        document.getElementById('detailsParticipants').textContent = 'Función en desarrollo';
    } else {
        reunionSection.classList.add('d-none');
    }

    // Mostrar modal
    new bootstrap.Modal(document.getElementById('taskDetailsModal')).show();
}

// Editar tarea
function editTask(taskId) {
    currentTaskId = taskId;
    const task = currentTasks.find(t => t.id == taskId);

    if (!task) {
        console.error('No se encontró la tarea con ID:', taskId);
        alert('No se pudo encontrar la información de esta tarea.');
        return;
    }

    // Decidir qué modal mostrar según si es reunión o tarea
    if (task.esReunion) {
        // Llenar el formulario de reunión
        document.getElementById('reunionId').value = task.id;
        document.getElementById('reunionTitle').value = task.titulo;
        document.getElementById('reunionDescription').value = task.descripcion;
        document.getElementById('reunionDate').value = formatDateForInput(task.fechaLimite);
        document.getElementById('reunionLocation').value = task.ubicacion || '';
        document.getElementById('reunionPriority').value = task.prioridad;
        document.getElementById('reunionComments').value = task.comentarios || '';

        // Mostrar modal de reunión
        new bootstrap.Modal(document.getElementById('reunionModal')).show();
    } else {
        // Llenar el formulario de tarea
        document.getElementById('taskId').value = task.id;
        document.getElementById('taskTitle').value = task.titulo;
        document.getElementById('taskDescription').value = task.descripcion;
        document.getElementById('taskDueDate').value = formatDateForInput(task.fechaLimite);
        document.getElementById('taskPriority').value = task.prioridad;
        document.getElementById('taskComments').value = task.comentarios || '';

        // Seleccionar el usuario asignado
        if (task.asignado) {
            document.getElementById('taskAssignee').value = task.asignado.id;
        }

        // Cambiar título del modal
        document.getElementById('taskModalTitle').textContent = 'Editar Tarea';

        // Mostrar modal de tarea
        new bootstrap.Modal(document.getElementById('taskModal')).show();
    }
}

// Guardar tarea
function saveTask() {
    const taskId = document.getElementById('taskId').value;
    const assigneeId = document.getElementById('taskAssignee').value;

    // Buscar usuario asignado
    const assignee = allUsers.find(u => u.id == assigneeId);

    // Verificar que se encontró el usuario asignado
    if (!assignee) {
        console.error('No se pudo encontrar el usuario con ID:', assigneeId);
        console.log('Usuarios disponibles:', allUsers);
        alert('Error: No se pudo encontrar el usuario asignado.');
        return;
    }

    const taskData = {
        titulo: document.getElementById('taskTitle').value,
        descripcion: document.getElementById('taskDescription').value,
        fechaLimite: document.getElementById('taskDueDate').value,
        prioridad: document.getElementById('taskPriority').value,
        comentarios: document.getElementById('taskComments').value,
        estado: 'PENDIENTE',
        esReunion: false,
        creador: currentUser,
        asignado: assignee
    };

    console.log('Datos de tarea a guardar:', taskData);

    let url = '/api/tareas';
    let method = 'POST';

    // Si es edición, añadir ID y cambiar método
    if (taskId) {
        // Preservar el estado actual si es una edición
        const existingTask = currentTasks.find(t => t.id == taskId);
        if (existingTask) {
            taskData.estado = existingTask.estado;
            taskData.id = existingTask.id;
            taskData.fechaCreacion = existingTask.fechaCreacion;
        }

        url = `/api/tareas/${taskId}`;
        method = 'PUT';
    }

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskData)
    })
    .then(response => {
        if (!response.ok) throw new Error('Error al guardar tarea: ' + response.status);
        return response.json();
    })
    .then(savedTask => {
        console.log('Tarea guardada exitosamente:', savedTask);
        // Cerrar modal y recargar tareas
        bootstrap.Modal.getInstance(document.getElementById('taskModal')).hide();
        document.getElementById('taskForm').reset();
        document.getElementById('taskId').value = '';
        document.getElementById('taskModalTitle').textContent = 'Nueva Tarea';
        // Esperar un breve momento para que los datos se actualicen en el servidor
        setTimeout(() => {
            loadTasks();
        }, 300);
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ha ocurrido un error al guardar la tarea: ' + error.message);
    });
}

// Guardar reunión
function saveReunion() {
    const reunionId = document.getElementById('reunionId').value;

    const reunionData = {
        titulo: document.getElementById('reunionTitle').value,
        descripcion: document.getElementById('reunionDescription').value,
        fechaLimite: document.getElementById('reunionDate').value,
        prioridad: document.getElementById('reunionPriority').value,
        comentarios: document.getElementById('reunionComments').value,
        ubicacion: document.getElementById('reunionLocation').value,
        estado: 'PENDIENTE',
        esReunion: true,
        creador: currentUser,
        asignado: currentUser // Por simplicidad, la reunión se asigna al creador
    };

    console.log('Datos de reunión a guardar:', reunionData);

    let url = '/api/tareas';
    let method = 'POST';

    // Si es edición, añadir ID y cambiar método
    if (reunionId) {
        // Preservar el estado actual si es una edición
        const existingReunion = currentTasks.find(t => t.id == reunionId);
        if (existingReunion) {
            reunionData.estado = existingReunion.estado;
            reunionData.id = existingReunion.id;
            reunionData.fechaCreacion = existingReunion.fechaCreacion;
            reunionData.asignado = existingReunion.asignado;
        }

        url = `/api/tareas/${reunionId}`;
        method = 'PUT';
    }

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reunionData)
    })
    .then(response => {
        if (!response.ok) throw new Error('Error al guardar reunión: ' + response.status);
        return response.json();
    })
    .then(savedReunion => {
        console.log('Reunión guardada exitosamente:', savedReunion);
        // Cerrar modal y recargar tareas
        bootstrap.Modal.getInstance(document.getElementById('reunionModal')).hide();
        document.getElementById('reunionForm').reset();
        document.getElementById('reunionId').value = '';
        loadTasks();
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ha ocurrido un error al guardar la reunión: ' + error.message);
    });
}

// Cambiar estado de tarea
function changeTaskStatus(taskId, newStatus) {
    fetch(`/api/tareas/${taskId}/estado`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: newStatus })
    })
    .then(response => {
        if (!response.ok) throw new Error('Error al cambiar estado: ' + response.status);
        return response.json();
    })
    .then(updatedTask => {
        console.log('Estado de tarea actualizado:', updatedTask);
        // Cerrar modal y recargar tareas
        bootstrap.Modal.getInstance(document.getElementById('taskDetailsModal')).hide();
        loadTasks();
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ha ocurrido un error al cambiar el estado de la tarea: ' + error.message);
    });
}

// Utilidades
function formatDate(dateStr) {
    if (!dateStr) return 'No especificada';
    const date = new Date(dateStr);
    return date.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
    });
}

function formatDateTime(dateTimeStr) {
    if (!dateTimeStr) return 'No especificada';
    const date = new Date(dateTimeStr);
    return date.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDateForInput(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toISOString().split('T')[0];
}

function getPriorityBadgeColor(priority) {
    switch (priority) {
        case 'BAJA': return 'success';
        case 'MEDIA': return 'info';
        case 'ALTA': return 'warning';
        case 'CRITICA': return 'danger';
        default: return 'secondary';
    }
}
