package com.login.guzpasen.controllers;

import com.login.guzpasen.models.Rol;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.services.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class AuthControllerTest {

    @Mock
    private UsuarioService usuarioService;

    @InjectMocks
    private AuthController authController;

    private Usuario usuario;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Usuario");
        usuario.setApellidos("Test");
        usuario.setEmail("usuario@test.com");
        usuario.setPassword("password");
        usuario.setRol(Rol.PROFESOR);
        usuario.setActivo(true);
    }

    @Test
    public void testLoginExitoso() {
        // Arrange
        Map<String, String> credenciales = Map.of(
                "email", "usuario@test.com",
                "password", "password"
        );

        when(usuarioService.getUsuarioByEmail("usuario@test.com")).thenReturn(Optional.of(usuario));

        // Act
        ResponseEntity<?> response = authController.login(credenciales);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        @SuppressWarnings("unchecked")
        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertEquals(1L, responseBody.get("id"));
        assertEquals("Usuario", responseBody.get("nombre"));
        assertEquals("Test", responseBody.get("apellidos"));
        assertEquals("usuario@test.com", responseBody.get("email"));
        assertEquals(Rol.PROFESOR, responseBody.get("rol"));
        assertEquals(true, responseBody.get("activo"));
    }

    @Test
    public void testLoginCredencialesInvalidas() {
        // Arrange
        Map<String, String> credenciales = Map.of(
                "email", "usuario@test.com",
                "password", "passwordIncorrecto"
        );

        when(usuarioService.getUsuarioByEmail("usuario@test.com")).thenReturn(Optional.of(usuario));

        // Act
        ResponseEntity<?> response = authController.login(credenciales);

        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    public void testLoginUsuarioNoExistente() {
        // Arrange
        Map<String, String> credenciales = Map.of(
                "email", "noexiste@test.com",
                "password", "password"
        );

        when(usuarioService.getUsuarioByEmail("noexiste@test.com")).thenReturn(Optional.empty());

        // Act
        ResponseEntity<?> response = authController.login(credenciales);

        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    public void testRegistroExitoso() {
        // Arrange
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setEmail("nuevo@test.com");
        nuevoUsuario.setPassword("password");
        nuevoUsuario.setNombre("Nuevo");
        nuevoUsuario.setApellidos("Usuario");

        when(usuarioService.getUsuarioByEmail("nuevo@test.com")).thenReturn(Optional.empty());
        when(usuarioService.createUsuario(any(Usuario.class))).thenReturn(usuario);

        // Act
        ResponseEntity<?> response = authController.registro(nuevoUsuario);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        verify(usuarioService, times(1)).createUsuario(any(Usuario.class));
    }

    @Test
    public void testRegistroEmailYaExistente() {
        // Arrange
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setEmail("usuario@test.com");

        when(usuarioService.getUsuarioByEmail("usuario@test.com")).thenReturn(Optional.of(usuario));

        // Act
        ResponseEntity<?> response = authController.registro(nuevoUsuario);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        verify(usuarioService, never()).createUsuario(any(Usuario.class));
    }

    @Test
    public void testObtenerPerfilExistente() {
        // Arrange
        when(usuarioService.getUsuarioByEmail("usuario@test.com")).thenReturn(Optional.of(usuario));

        // Act
        ResponseEntity<?> response = authController.obtenerPerfil("usuario@test.com");

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void testObtenerPerfilNoExistente() {
        // Arrange
        when(usuarioService.getUsuarioByEmail("noexiste@test.com")).thenReturn(Optional.empty());

        // Act
        ResponseEntity<?> response = authController.obtenerPerfil("noexiste@test.com");

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
}
