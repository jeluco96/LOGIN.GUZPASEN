package com.login.guzpasen.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.PrioridadTarea;
import com.login.guzpasen.models.Tarea;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.repositories.TareaRepository;
import com.login.guzpasen.repositories.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Prueba de integración para el flujo completo de gestión de tareas.
 * Esta prueba valida la interacción entre controladores, servicios y repositorios
 * relacionados con la creación, modificación y consulta de tareas.
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
public class TareaGestionIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TareaRepository tareaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario usuarioCreador;
    private Usuario usuarioAsignado;

    @BeforeEach
    public void setup() {
        // Limpiar datos anteriores
        tareaRepository.deleteAll();
        usuarioRepository.deleteAll();

        // Crear usuarios de prueba
        usuarioCreador = new Usuario();
        usuarioCreador.setNombre("Creador");
        usuarioCreador.setApellidos("Test");
        usuarioCreador.setEmail("creador@test.com");
        usuarioCreador.setPassword("password123");
        usuarioCreador.setActivo(true);
        usuarioCreador = usuarioRepository.save(usuarioCreador);

        usuarioAsignado = new Usuario();
        usuarioAsignado.setNombre("Asignado");
        usuarioAsignado.setApellidos("Test");
        usuarioAsignado.setEmail("asignado@test.com");
        usuarioAsignado.setPassword("password123");
        usuarioAsignado.setActivo(true);
        usuarioAsignado = usuarioRepository.save(usuarioAsignado);
    }

    @Test
    public void testFlujoCompletoGestionTareas() throws Exception {
        // 1. Crear una nueva tarea
        Tarea nuevaTarea = new Tarea();
        nuevaTarea.setTitulo("Tarea de prueba");
        nuevaTarea.setDescripcion("Descripción de la tarea de prueba");
        nuevaTarea.setFechaLimite(LocalDate.now().plusDays(7));
        nuevaTarea.setCreador(usuarioCreador);
        nuevaTarea.setAsignado(usuarioAsignado);
        nuevaTarea.setPrioridad(PrioridadTarea.ALTA);

        String tareaJson = objectMapper.writeValueAsString(nuevaTarea);

        MvcResult resultadoCreacion = mockMvc.perform(post("/api/tareas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(tareaJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.titulo").value("Tarea de prueba"))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andReturn();

        // Extraer el ID de la tarea creada
        String responseJson = resultadoCreacion.getResponse().getContentAsString();
        Long tareaId = objectMapper.readTree(responseJson).get("id").asLong();

        // 2. Obtener la tarea por su ID
        mockMvc.perform(get("/api/tareas/" + tareaId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(tareaId))
                .andExpect(jsonPath("$.titulo").value("Tarea de prueba"))
                .andExpect(jsonPath("$.descripcion").value("Descripción de la tarea de prueba"));

        // 3. Actualizar la tarea
        nuevaTarea.setId(tareaId);
        nuevaTarea.setTitulo("Tarea actualizada");
        nuevaTarea.setDescripcion("Descripción actualizada");

        mockMvc.perform(put("/api/tareas/" + tareaId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevaTarea)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Tarea actualizada"))
                .andExpect(jsonPath("$.descripcion").value("Descripción actualizada"));

        // 4. Cambiar el estado de la tarea
        Map<String, String> cambioEstado = new HashMap<>();
        cambioEstado.put("estado", "EN_PROGRESO");

        mockMvc.perform(patch("/api/tareas/" + tareaId + "/estado")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cambioEstado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("EN_PROGRESO"));

        // 5. Obtener tareas por usuario asignado
        mockMvc.perform(get("/api/tareas/usuario/" + usuarioAsignado.getId() + "/asignadas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id").value(tareaId));

        // 6. Obtener tareas por usuario creador
        mockMvc.perform(get("/api/tareas/usuario/" + usuarioCreador.getId() + "/creadas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id").value(tareaId));

        // 7. Marcar la tarea como completada
        cambioEstado.put("estado", "COMPLETADA");

        mockMvc.perform(patch("/api/tareas/" + tareaId + "/estado")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cambioEstado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("COMPLETADA"));

        // 8. Verificar que la tarea está en la base de datos con el estado correcto
        Tarea tareaGuardada = tareaRepository.findById(tareaId).orElse(null);
        assertNotNull(tareaGuardada);
        assertEquals("Tarea actualizada", tareaGuardada.getTitulo());
        assertEquals("Descripción actualizada", tareaGuardada.getDescripcion());
        assertEquals(EstadoTarea.COMPLETADA, tareaGuardada.getEstado());
        assertEquals(usuarioCreador.getId(), tareaGuardada.getCreador().getId());
        assertEquals(usuarioAsignado.getId(), tareaGuardada.getAsignado().getId());
    }

    @Test
    public void testFlujoReuniones() throws Exception {
        // 1. Crear varias reuniones
        for (int i = 1; i <= 3; i++) {
            Tarea reunion = new Tarea();
            reunion.setTitulo("Reunión " + i);
            reunion.setDescripcion("Descripción de la reunión " + i);
            reunion.setFechaLimite(LocalDate.now().plusDays(i));
            reunion.setCreador(usuarioCreador);
            reunion.setAsignado(usuarioAsignado);
            reunion.setEsReunion(true);
            reunion.setUbicacion("Sala " + i);

            mockMvc.perform(post("/api/tareas")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(reunion)))
                    .andExpect(status().isCreated());
        }

        // 2. Obtener todas las reuniones
        mockMvc.perform(get("/api/tareas/reuniones"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(3)));

        // 3. Obtener reuniones por usuario
        mockMvc.perform(get("/api/tareas/usuario/" + usuarioAsignado.getId() + "/reuniones"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(3)));

        // 4. Verificar que las reuniones están en la base de datos
        List<Tarea> reuniones = tareaRepository.findByEsReunionTrue();
        assertEquals(3, reuniones.size());

        for (Tarea reunion : reuniones) {
            assertTrue(reunion.isEsReunion());
            assertNotNull(reunion.getUbicacion());
            assertTrue(reunion.getTitulo().startsWith("Reunión"));
        }
    }
}
