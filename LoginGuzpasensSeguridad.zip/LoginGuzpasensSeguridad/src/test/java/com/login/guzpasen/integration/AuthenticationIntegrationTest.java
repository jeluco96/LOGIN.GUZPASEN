package com.login.guzpasen.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.login.guzpasen.models.Rol;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.repositories.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Prueba de integración para el flujo completo de autenticación.
 * Esta prueba valida la interacción entre los controladores, servicios y repositorios
 * relacionados con la autenticación y gestión de usuarios.
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
public class AuthenticationIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario usuarioPrueba;

    @BeforeEach
    public void setup() {
        // Limpiar usuarios de prueba anteriores
        usuarioRepository.deleteAll();

        // Crear un usuario de prueba
        usuarioPrueba = new Usuario();
        usuarioPrueba.setNombre("Integración");
        usuarioPrueba.setApellidos("Test");
        usuarioPrueba.setEmail("integracion@test.com");
        usuarioPrueba.setPassword("password123");
        usuarioPrueba.setRol(Rol.PROFESOR);
        usuarioPrueba.setActivo(true);

        usuarioPrueba = usuarioRepository.save(usuarioPrueba);
    }

    @Test
    public void testFlujoCompletoAutenticacion() throws Exception {
        // 1. Registrar un nuevo usuario
        Map<String, Object> nuevoUsuario = new HashMap<>();
        nuevoUsuario.put("nombre", "Nuevo");
        nuevoUsuario.put("apellidos", "Usuario");
        nuevoUsuario.put("email", "nuevo@test.com");
        nuevoUsuario.put("password", "clave123");

        MvcResult resultRegistro = mockMvc.perform(post("/api/auth/registro")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoUsuario)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombre").value("Nuevo"))
                .andExpect(jsonPath("$.email").value("nuevo@test.com"))
                .andExpect(jsonPath("$.rol").value("PROFESOR"))
                .andReturn();

        // 2. Intentar iniciar sesión con credenciales inválidas
        Map<String, String> credencialesInvalidas = new HashMap<>();
        credencialesInvalidas.put("email", "nuevo@test.com");
        credencialesInvalidas.put("password", "claveIncorrecta");

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(credencialesInvalidas)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.mensaje").value("Credenciales inválidas"));

        // 3. Iniciar sesión con credenciales correctas
        Map<String, String> credencialesValidas = new HashMap<>();
        credencialesValidas.put("email", "nuevo@test.com");
        credencialesValidas.put("password", "clave123");

        MvcResult resultLogin = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(credencialesValidas)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombre").value("Nuevo"))
                .andExpect(jsonPath("$.email").value("nuevo@test.com"))
                .andReturn();

        // 4. Consultar perfil de usuario
        mockMvc.perform(get("/api/auth/perfil")
                .param("email", "nuevo@test.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Nuevo"))
                .andExpect(jsonPath("$.apellidos").value("Usuario"));

        // 5. Cambiar contraseña
        Map<String, String> cambioPassword = new HashMap<>();
        cambioPassword.put("email", "nuevo@test.com");
        cambioPassword.put("passwordActual", "clave123");
        cambioPassword.put("nuevaPassword", "nuevaClave456");

        mockMvc.perform(post("/api/auth/cambiar-password")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cambioPassword)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mensaje").value("Contraseña actualizada correctamente"));

        // 6. Verificar que se puede iniciar sesión con la nueva contraseña
        Map<String, String> nuevasCredenciales = new HashMap<>();
        nuevasCredenciales.put("email", "nuevo@test.com");
        nuevasCredenciales.put("password", "nuevaClave456");

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevasCredenciales)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Nuevo"));

        // 7. Verificar que el usuario está en la base de datos
        Usuario usuarioGuardado = usuarioRepository.findByEmail("nuevo@test.com").orElse(null);
        assertNotNull(usuarioGuardado);
        assertEquals("Nuevo", usuarioGuardado.getNombre());
        assertEquals("Usuario", usuarioGuardado.getApellidos());
        assertEquals("nuevaClave456", usuarioGuardado.getPassword());
        assertEquals(Rol.PROFESOR, usuarioGuardado.getRol());
        assertTrue(usuarioGuardado.isActivo());
    }
}
