package com.login.guzpasen.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EstadoTareaTest {

    @Test
    public void testEnumValues() {
        // Verificar que existen los valores esperados en la enumeración
        assertEquals(5, EstadoTarea.values().length);
        assertEquals(EstadoTarea.PENDIENTE, EstadoTarea.valueOf("PENDIENTE"));
        assertEquals(EstadoTarea.EN_PROGRESO, EstadoTarea.valueOf("EN_PROGRESO"));
        assertEquals(EstadoTarea.COMPLETADA, EstadoTarea.valueOf("COMPLETADA"));
        assertEquals(EstadoTarea.CANCELADA, EstadoTarea.valueOf("CANCELADA"));
        assertEquals(EstadoTarea.RETRASADA, EstadoTarea.valueOf("RETRASADA"));
    }

    @Test
    public void testEnumToString() {
        // Verificar la representación en cadena de los valores enum
        assertEquals("PENDIENTE", EstadoTarea.PENDIENTE.toString());
        assertEquals("EN_PROGRESO", EstadoTarea.EN_PROGRESO.toString());
        assertEquals("COMPLETADA", EstadoTarea.COMPLETADA.toString());
        assertEquals("CANCELADA", EstadoTarea.CANCELADA.toString());
        assertEquals("RETRASADA", EstadoTarea.RETRASADA.toString());
    }

    @Test
    public void testEnumOrdinals() {
        // Verificar que los ordinales están correctamente asignados
        assertEquals(0, EstadoTarea.PENDIENTE.ordinal());
        assertEquals(1, EstadoTarea.EN_PROGRESO.ordinal());
        assertEquals(2, EstadoTarea.COMPLETADA.ordinal());
        assertEquals(3, EstadoTarea.CANCELADA.ordinal());
        assertEquals(4, EstadoTarea.RETRASADA.ordinal());
    }
}
