package com.login.guzpasen.services;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.repositories.TareaRepository;
import com.login.guzpasen.services.impl.TareaServiceImpl;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class TareaServiceTest {

    @Mock
    private TareaRepository tareaRepository;

    @InjectMocks
    private TareaServiceImpl tareaService;

    private Tarea tarea;
    private Usuario usuario;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Usuario");
        usuario.setApellidos("Test");
        usuario.setEmail("usuario@test.com");

        tarea = new Tarea();
        tarea.setId(1L);
        tarea.setTitulo("Tarea de prueba");
        tarea.setDescripcion("Descripción de prueba");
        tarea.setFechaLimite(LocalDate.now().plusDays(5));
        tarea.setEstado(EstadoTarea.PENDIENTE);
        tarea.setCreador(usuario);
        tarea.setAsignado(usuario);
    }

    @Test
    public void testCrearTarea() {
        // Arrange
        when(tareaRepository.save(any(Tarea.class))).thenReturn(tarea);

        // Act
        Tarea tareaCreada = tareaService.crearTarea(new Tarea());

        // Assert
        assertNotNull(tareaCreada);
        assertEquals(1L, tareaCreada.getId());
        assertEquals("Tarea de prueba", tareaCreada.getTitulo());
        verify(tareaRepository, times(1)).save(any(Tarea.class));
    }

    @Test
    public void testObtenerTodasLasTareas() {
        // Arrange
        when(tareaRepository.findAll()).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaService.obtenerTodasLasTareas();

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        assertEquals("Tarea de prueba", tareas.get(0).getTitulo());
    }

    @Test
    public void testObtenerTareaPorId() {
        // Arrange
        when(tareaRepository.findById(1L)).thenReturn(Optional.of(tarea));

        // Act
        Optional<Tarea> resultado = tareaService.obtenerTareaPorId(1L);

        // Assert
        assertTrue(resultado.isPresent());
        assertEquals("Tarea de prueba", resultado.get().getTitulo());
    }

    @Test
    public void testActualizarTarea() {
        // Arrange
        Tarea tareaActualizada = new Tarea();
        tareaActualizada.setTitulo("Tarea actualizada");
        tareaActualizada.setDescripcion("Nueva descripción");

        when(tareaRepository.findById(1L)).thenReturn(Optional.of(tarea));
        when(tareaRepository.save(any(Tarea.class))).thenReturn(tarea);

        // Act
        Tarea resultado = tareaService.actualizarTarea(1L, tareaActualizada);

        // Assert
        assertNotNull(resultado);
        assertEquals("Tarea actualizada", tarea.getTitulo());
        assertEquals("Nueva descripción", tarea.getDescripcion());
        verify(tareaRepository, times(1)).save(tarea);
    }

    @Test
    public void testActualizarTareaInexistente() {
        // Arrange
        when(tareaRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(EntityNotFoundException.class, () -> {
            tareaService.actualizarTarea(99L, new Tarea());
        });
    }

    @Test
    public void testEliminarTarea() {
        // Act
        tareaService.eliminarTarea(1L);

        // Assert
        verify(tareaRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testCambiarEstadoTarea() {
        // Arrange
        when(tareaRepository.findById(1L)).thenReturn(Optional.of(tarea));
        when(tareaRepository.save(any(Tarea.class))).thenReturn(tarea);

        // Act
        Tarea resultado = tareaService.cambiarEstadoTarea(1L, EstadoTarea.EN_PROGRESO);

        // Assert
        assertNotNull(resultado);
        assertEquals(EstadoTarea.EN_PROGRESO, resultado.getEstado());
    }

    @Test
    public void testObtenerTareasPorUsuarioAsignado() {
        // Arrange
        when(tareaRepository.findByAsignadoId(1L)).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaService.obtenerTareasPorUsuarioAsignado(1L);

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        assertEquals(1L, tareas.get(0).getId());
    }

    @Test
    public void testObtenerTareasPorUsuarioCreador() {
        // Arrange
        when(tareaRepository.findByCreadorId(1L)).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaService.obtenerTareasPorUsuarioCreador(1L);

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        assertEquals(1L, tareas.get(0).getId());
    }

    @Test
    public void testObtenerTareasPendientesPorUsuario() {
        // Arrange
        when(tareaRepository.findByAsignadoIdAndEstado(1L, EstadoTarea.PENDIENTE))
                .thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaService.obtenerTareasPendientesPorUsuario(1L);

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        assertEquals(EstadoTarea.PENDIENTE, tareas.get(0).getEstado());
    }

    @Test
    public void testObtenerTareasProximasAVencer() {
        // Arrange
        LocalDate fechaLimite = LocalDate.now().plusDays(7);
        when(tareaRepository.findByFechaLimiteLessThanEqual(any(LocalDate.class)))
                .thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaService.obtenerTareasProximasAVencer();

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        verify(tareaRepository).findByFechaLimiteLessThanEqual(any(LocalDate.class));
    }

    @Test
    public void testObtenerReuniones() {
        // Arrange
        tarea.setEsReunion(true);
        when(tareaRepository.findByEsReunionTrue()).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> reuniones = tareaService.obtenerReuniones();

        // Assert
        assertNotNull(reuniones);
        assertEquals(1, reuniones.size());
        assertTrue(reuniones.get(0).isEsReunion());
    }

    @Test
    public void testObtenerReunionesPorUsuario() {
        // Arrange
        tarea.setEsReunion(true);
        when(tareaRepository.findByAsignadoIdAndEsReunionTrue(1L)).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> reuniones = tareaService.obtenerReunionesPorUsuario(1L);

        // Assert
        assertNotNull(reuniones);
        assertEquals(1, reuniones.size());
        assertTrue(reuniones.get(0).isEsReunion());
        assertEquals(1L, reuniones.get(0).getAsignado().getId());
    }

    @Test
    public void testCambiarEstadoTareaInexistente() {
        // Arrange
        when(tareaRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(EntityNotFoundException.class, () -> {
            tareaService.cambiarEstadoTarea(99L, EstadoTarea.COMPLETADA);
        });
    }
}
