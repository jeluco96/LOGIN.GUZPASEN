package com.login.guzpasen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = com.login.guzpasen.GuzpasenApplication.class)
class LoginGuzpasenApplicationTests {

	@Autowired
	private ApplicationContext applicationContext;

	@Test
	void contextLoads() {
		assertNotNull(applicationContext);
	}

	@Test
	void applicationStarts() {
		com.login.guzpasen.GuzpasenApplication.main(new String[] {});
	}

}
