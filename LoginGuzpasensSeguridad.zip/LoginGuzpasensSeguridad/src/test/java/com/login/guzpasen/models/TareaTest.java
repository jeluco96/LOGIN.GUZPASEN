
package com.login.guzpasen.models;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions .*;

        public class TareaTest {

            @Test
            public void testCreacionTarea() {
                // Arrange & Act
                Tarea tarea = new Tarea();
                tarea.setId(1L);
                tarea.setTitulo("Tarea de prueba");
                tarea.setDescripcion("Descripción de prueba");
                tarea.setFechaLimite(LocalDate.now());
                tarea.setEstado(EstadoTarea.PENDIENTE);
                tarea.setEsReunion(true);
                tarea.setUbicacion("Sala de reuniones");

                // Assert
                assertEquals(1L, tarea.getId());
                assertEquals("Tarea de prueba", tarea.getTitulo());
                assertEquals("Descripción de prueba", tarea.getDescripcion());
                assertNotNull(tarea.getFechaLimite());
                assertEquals(EstadoTarea.PENDIENTE, tarea.getEstado());
                assertTrue(tarea.isEsReunion());
                assertEquals("Sala de reuniones", tarea.getUbicacion());
            }

            @Test
            public void testConstructorTarea() {
                // Arrange
                Usuario creador = new Usuario();
                creador.setId(1L);
                creador.setNombre("Usuario Creador");

                Usuario asignado = new Usuario();
                asignado.setId(2L);
                asignado.setNombre("Usuario Asignado");

                LocalDate fechaLimite = LocalDate.now().plusDays(7);

                // Act
                Tarea tarea = new Tarea();
                tarea.setCreador(creador);
                tarea.setAsignado(asignado);
                tarea.setTitulo("Tarea con usuarios");
                tarea.setFechaLimite(fechaLimite);

                // Assert
                assertEquals("Tarea con usuarios", tarea.getTitulo());
                assertNotNull(tarea.getCreador());
                assertEquals(1L, tarea.getCreador().getId());
                assertNotNull(tarea.getAsignado());
                assertEquals(2L, tarea.getAsignado().getId());
                assertEquals(fechaLimite, tarea.getFechaLimite());
            }

            @Test
            public void testIgualdadTareas() {
                // Arrange
                Tarea tarea1 = new Tarea();
                tarea1.setId(1L);

                Tarea tarea2 = new Tarea();
                tarea2.setId(1L);

                Tarea tarea3 = new Tarea();
                tarea3.setId(2L);

                // Assert - Reflexividad
                assertEquals(tarea1, tarea1);

                // Assert - Simetría
                assertEquals(tarea1, tarea2);
                assertEquals(tarea2, tarea1);

                // Assert - Transitividad
                assertNotEquals(tarea1, tarea3);
                assertNotEquals(tarea2, tarea3);

                // Assert - Consistencia
                assertEquals(tarea1.hashCode(), tarea2.hashCode());
                assertNotEquals(tarea1.hashCode(), tarea3.hashCode());
            }
        }

