package com.login.guzpasen.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.models.Rol;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.repositories.ModuloRepository;
import com.login.guzpasen.repositories.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Prueba de integración para el flujo de asignación de módulos a usuarios.
 * Esta prueba valida la interacción entre controladores, servicios y repositorios
 * relacionados con la gestión de módulos y su asignación a usuarios.
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
@Transactional
public class ModuloAsignacionIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ModuloRepository moduloRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario administrador;
    private Usuario profesor;

    @BeforeEach
    public void setup() {
        // Limpiar datos anteriores
        usuarioRepository.deleteAll();
        moduloRepository.deleteAll();

        // Crear usuarios de prueba
        administrador = new Usuario();
        administrador.setNombre("Admin");
        administrador.setApellidos("Test");
        administrador.setEmail("admin@test.com");
        administrador.setPassword("password123");
        administrador.setRol(Rol.ADMINISTRADOR);
        administrador.setActivo(true);
        administrador = usuarioRepository.save(administrador);

        profesor = new Usuario();
        profesor.setNombre("Profesor");
        profesor.setApellidos("Test");
        profesor.setEmail("profesor@test.com");
        profesor.setPassword("password123");
        profesor.setRol(Rol.PROFESOR);
        profesor.setActivo(true);
        profesor = usuarioRepository.save(profesor);
    }

    @Test
    public void testFlujoGestionModulos() throws Exception {
        // 1. Crear varios módulos
        for (int i = 1; i <= 3; i++) {
            Modulo modulo = new Modulo();
            modulo.setNombre("Módulo " + i);
            modulo.setDescripcion("Descripción del módulo " + i);
            modulo.setIcono("icono-" + i + ".png");

            mockMvc.perform(post("/api/modulos")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(modulo)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id").exists())
                    .andExpect(jsonPath("$.nombre").value("Módulo " + i));
        }

        // 2. Obtener todos los módulos
        mockMvc.perform(get("/api/modulos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(3)));

        // 3. Asignar módulos a un rol (utilizando el endpoint específico para esto)
        // Asumiendo que existe un endpoint para asignar módulos a roles
        Modulo primerModulo = moduloRepository.findAll().get(0);

        mockMvc.perform(post("/api/roles/asignarModuloARol")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(Map.of(
                        "rol", "PROFESOR",
                        "moduloId", primerModulo.getId()
                ))))
                .andExpect(status().isOk());

        // 4. Verificar la asignación de módulos al rol
        mockMvc.perform(get("/api/roles/modulos/PROFESOR"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id").value(primerModulo.getId()));

        // 5. Asignar manualmente un módulo a un usuario específico
        Usuario usuario = usuarioRepository.findById(profesor.getId()).orElseThrow();
        Set<Modulo> modulos = new HashSet<>();
        modulos.add(primerModulo);
        usuario.setModulos(modulos);
        usuarioRepository.save(usuario);

        // 6. Verificar que el módulo está asignado al usuario en la base de datos
        Usuario usuarioConModulos = usuarioRepository.findById(profesor.getId()).orElseThrow();
        assertNotNull(usuarioConModulos.getModulos());
        assertEquals(1, usuarioConModulos.getModulos().size());
        assertTrue(usuarioConModulos.getModulos().stream()
                .anyMatch(m -> m.getId().equals(primerModulo.getId())));

        // 7. Quitar módulo del rol
        mockMvc.perform(post("/api/roles/eliminarModuloDeRol")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(Map.of(
                        "rol", "PROFESOR",
                        "moduloId", primerModulo.getId()
                ))))
                .andExpect(status().isOk());

        // 8. Verificar que ya no hay módulos asignados al rol
        mockMvc.perform(get("/api/roles/modulos/PROFESOR"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    public void testActualizacionModulo() throws Exception {
        // 1. Crear un nuevo módulo
        Modulo modulo = new Modulo();
        modulo.setNombre("Módulo Original");
        modulo.setDescripcion("Descripción original");
        modulo.setIcono("icono-original.png");

        String responseJson = mockMvc.perform(post("/api/modulos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(modulo)))
                .andExpect(status().isCreated())
                .andReturn()
                .getResponse()
                .getContentAsString();

        Long moduloId = objectMapper.readTree(responseJson).get("id").asLong();

        // 2. Actualizar el módulo
        modulo.setNombre("Módulo Actualizado");
        modulo.setDescripcion("Descripción actualizada");
        modulo.setIcono("icono-actualizado.png");

        mockMvc.perform(put("/api/modulos/" + moduloId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(modulo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Módulo Actualizado"))
                .andExpect(jsonPath("$.descripcion").value("Descripción actualizada"))
                .andExpect(jsonPath("$.icono").value("icono-actualizado.png"));

        // 3. Verificar que el módulo se actualizó en la base de datos
        Modulo moduloActualizado = moduloRepository.findById(moduloId).orElseThrow();
        assertEquals("Módulo Actualizado", moduloActualizado.getNombre());
        assertEquals("Descripción actualizada", moduloActualizado.getDescripcion());
        assertEquals("icono-actualizado.png", moduloActualizado.getIcono());
    }
}
