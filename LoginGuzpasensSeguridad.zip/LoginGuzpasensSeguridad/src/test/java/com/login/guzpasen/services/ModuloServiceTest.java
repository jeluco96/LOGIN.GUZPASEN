package com.login.guzpasen.services;

import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.repositories.ModuloRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ModuloServiceTest {

    @Mock
    private ModuloRepository moduloRepository;

    private Modulo modulo;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        modulo = new Modulo();
        modulo.setId(1L);
        modulo.setNombre("Gestión de Tareas");
        modulo.setDescripcion("Módulo para gestionar tareas del sistema");
        modulo.setIcono("task-icon.png");
    }

    @Test
    public void testGuardarModulo() {
        // Arrange
        when(moduloRepository.save(any(Modulo.class))).thenReturn(modulo);

        // Act
        Modulo resultado = moduloRepository.save(new Modulo());

        // Assert
        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Gestión de Tareas", resultado.getNombre());
        verify(moduloRepository, times(1)).save(any(Modulo.class));
    }

    @Test
    public void testObtenerTodosLosModulos() {
        // Arrange
        when(moduloRepository.findAll()).thenReturn(Arrays.asList(modulo));

        // Act
        List<Modulo> modulos = moduloRepository.findAll();

        // Assert
        assertNotNull(modulos);
        assertEquals(1, modulos.size());
        assertEquals("Gestión de Tareas", modulos.get(0).getNombre());
    }

    @Test
    public void testObtenerModuloPorId() {
        // Arrange
        when(moduloRepository.findById(1L)).thenReturn(Optional.of(modulo));

        // Act
        Optional<Modulo> resultado = moduloRepository.findById(1L);

        // Assert
        assertTrue(resultado.isPresent());
        assertEquals("Gestión de Tareas", resultado.get().getNombre());
    }

    @Test
    public void testObtenerModuloPorIdNoExistente() {
        // Arrange
        when(moduloRepository.findById(99L)).thenReturn(Optional.empty());

        // Act
        Optional<Modulo> resultado = moduloRepository.findById(99L);

        // Assert
        assertFalse(resultado.isPresent());
    }

    @Test
    public void testEliminarModulo() {
        // Act
        moduloRepository.deleteById(1L);

        // Assert
        verify(moduloRepository, times(1)).deleteById(1L);
    }
}
