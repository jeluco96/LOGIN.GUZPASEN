package com.login.guzpasen.models;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class UsuarioTest {

    @Test
    public void testCreacionUsuario() {
        // Arrange
        Usuario usuario = new Usuario();
        Set<Modulo> modulos = new HashSet<>();
        Modulo modulo = new Modulo();
        modulo.setId(1L);
        modulo.setNombre("Tareas");
        modulos.add(modulo);

        // Act
        usuario.setId(1L);
        usuario.setNombre("Juan");
        usuario.setApellidos("Pérez González");
        usuario.setEmail("juan.perez@ejemplo.com");
        usuario.setPassword("contraseña123");
        usuario.setRol(Rol.PROFESOR);
        usuario.setModulos(modulos);

        // Assert
        assertEquals(1L, usuario.getId());
        assertEquals("Juan", usuario.getNombre());
        assertEquals("Pérez González", usuario.getApellidos());
        assertEquals("juan.perez@ejemplo.com", usuario.getEmail());
        assertEquals("contraseña123", usuario.getPassword());
        assertEquals(Rol.PROFESOR, usuario.getRol());
        assertTrue(usuario.isActivo()); // Valor por defecto
        assertEquals(1, usuario.getModulos().size());
    }

    @Test
    public void testValoresPorDefecto() {
        // Arrange & Act
        Usuario usuario = new Usuario();

        // Assert
        assertTrue(usuario.isActivo());
        assertNull(usuario.getRol());
        assertNull(usuario.getModulos());
    }
}
