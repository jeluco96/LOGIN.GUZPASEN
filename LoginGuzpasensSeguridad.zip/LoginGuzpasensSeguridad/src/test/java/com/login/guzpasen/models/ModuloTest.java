package com.login.guzpasen.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ModuloTest {

    @Test
    public void testCreacionModulo() {
        // Arrange
        Modulo modulo = new Modulo();

        // Act
        modulo.setId(1L);
        modulo.setNombre("Gestión de Tareas");
        modulo.setDescripcion("Módulo para gestionar tareas del sistema");
        modulo.setIcono("task-icon.png");

        // Assert
        assertEquals(1L, modulo.getId());
        assertEquals("Gestión de Tareas", modulo.getNombre());
        assertEquals("Módulo para gestionar tareas del sistema", modulo.getDescripcion());
        assertEquals("task-icon.png", modulo.getIcono());
    }

    @Test
    public void testGettersYSetters() {
        // Arrange
        Modulo modulo = new Modulo();

        // Act & Assert - Comprobando que los getters y setters funcionan correctamente
        assertNull(modulo.getNombre());
        modulo.setNombre("Nuevo Módulo");
        assertEquals("Nuevo Módulo", modulo.getNombre());

        assertNull(modulo.getDescripcion());
        modulo.setDescripcion("Descripción de prueba");
        assertEquals("Descripción de prueba", modulo.getDescripcion());
    }
}
