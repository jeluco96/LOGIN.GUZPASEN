package com.login.guzpasen;

import com.login.guzpasen.controllers.AuthControllerTest;
import com.login.guzpasen.controllers.ModuloControllerTest;
import com.login.guzpasen.controllers.TareaControllerTest;
import com.login.guzpasen.integration.AuthenticationIntegrationTest;
import com.login.guzpasen.integration.ModuloAsignacionIntegrationTest;
import com.login.guzpasen.integration.TareaGestionIntegrationTest;
import com.login.guzpasen.models.EstadoTareaTest;
import com.login.guzpasen.models.ModuloTest;
import com.login.guzpasen.models.RolTest;
import com.login.guzpasen.models.TareaTest;
import com.login.guzpasen.models.UsuarioTest;
import com.login.guzpasen.services.ModuloServiceTest;
import com.login.guzpasen.services.TareaServiceTest;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

/**
 * Clase para ejecutar todas las pruebas unitarias como un conjunto (suite).
 * Esta clase utiliza JUnit 5 para agrupar todas las clases de prueba
 * y ejecutarlas en una sola ejecución.
 *
 * @author Guzpasen
 * @version 1.0
 * @since 2025-06-10
 */
@Suite
@SelectClasses({
    // Pruebas de modelos
    TareaTest.class,
    UsuarioTest.class,
    ModuloTest.class,
    RolTest.class,
    EstadoTareaTest.class,

    // Pruebas de servicios
    TareaServiceTest.class,
    ModuloServiceTest.class,

    // Pruebas de controladores
    TareaControllerTest.class,
    AuthControllerTest.class,
    ModuloControllerTest.class,


})
public class AllTestsSuite {
    // Esta clase no necesita ningún contenido,
    // solo sirve como punto de entrada para la suite de pruebas
}
