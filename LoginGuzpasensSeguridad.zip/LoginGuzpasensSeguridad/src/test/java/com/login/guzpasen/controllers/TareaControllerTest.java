package com.login.guzpasen.controllers;

import com.login.guzpasen.models.EstadoTarea;
import com.login.guzpasen.models.Tarea;
import com.login.guzpasen.models.Usuario;
import com.login.guzpasen.services.TareaService;
import com.login.guzpasen.services.UsuarioService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class TareaControllerTest {

    @Mock
    private TareaService tareaService;

    @Mock
    private UsuarioService usuarioService;

    @InjectMocks
    private TareaController tareaController;

    private Tarea tarea;
    private Usuario usuario;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Usuario");
        usuario.setApellidos("Test");
        usuario.setEmail("usuario@test.com");

        tarea = new Tarea();
        tarea.setId(1L);
        tarea.setTitulo("Tarea de prueba");
        tarea.setDescripcion("Descripción de prueba");
        tarea.setFechaLimite(LocalDate.now().plusDays(5));
        tarea.setEstado(EstadoTarea.PENDIENTE);
        tarea.setCreador(usuario);
        tarea.setAsignado(usuario);
    }

    @Test
    public void testCrearTarea() {
        // Arrange
        when(tareaService.crearTarea(any(Tarea.class))).thenReturn(tarea);

        // Act
        ResponseEntity<Tarea> response = tareaController.crearTarea(new Tarea());

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
    }

    @Test
    public void testObtenerTodasLasTareas() {
        // Arrange
        when(tareaService.obtenerTodasLasTareas()).thenReturn(Arrays.asList(tarea));

        // Act
        List<Tarea> tareas = tareaController.obtenerTodasLasTareas();

        // Assert
        assertNotNull(tareas);
        assertEquals(1, tareas.size());
        assertEquals("Tarea de prueba", tareas.get(0).getTitulo());
    }

    @Test
    public void testObtenerTareaPorIdExistente() {
        // Arrange
        when(tareaService.obtenerTareaPorId(1L)).thenReturn(Optional.of(tarea));

        // Act
        ResponseEntity<Tarea> response = tareaController.obtenerTareaPorId(1L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
    }

    @Test
    public void testObtenerTareaPorIdNoExistente() {
        // Arrange
        when(tareaService.obtenerTareaPorId(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Tarea> response = tareaController.obtenerTareaPorId(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testActualizarTareaExistente() {
        // Arrange
        when(tareaService.actualizarTarea(eq(1L), any(Tarea.class))).thenReturn(tarea);

        // Act
        ResponseEntity<Tarea> response = tareaController.actualizarTarea(1L, new Tarea());

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void testActualizarTareaNoExistente() {
        // Arrange
        when(tareaService.actualizarTarea(eq(99L), any(Tarea.class)))
                .thenThrow(new EntityNotFoundException("Tarea no encontrada"));

        // Act
        ResponseEntity<Tarea> response = tareaController.actualizarTarea(99L, new Tarea());

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testEliminarTarea() {
        // Act
        ResponseEntity<Void> response = tareaController.eliminarTarea(1L);

        // Assert
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        verify(tareaService, times(1)).eliminarTarea(1L);
    }

    @Test
    public void testCambiarEstadoTarea() {
        // Arrange
        Map<String, String> body = Map.of("estado", "EN_PROGRESO");
        when(tareaService.cambiarEstadoTarea(eq(1L), any(EstadoTarea.class))).thenReturn(tarea);

        // Act
        ResponseEntity<Tarea> response = tareaController.cambiarEstadoTarea(1L, body);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(tareaService, times(1)).cambiarEstadoTarea(eq(1L), any(EstadoTarea.class));
    }

    @Test
    public void testCambiarEstadoTareaConEstadoInvalido() {
        // Arrange
        Map<String, String> body = Map.of("estado", "ESTADO_INVALIDO");

        // Act
        ResponseEntity<Tarea> response = tareaController.cambiarEstadoTarea(1L, body);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testObtenerTareasPorUsuarioAsignado() {
        // Arrange
        when(usuarioService.getUsuarioById(1L)).thenReturn(Optional.of(usuario));
        when(tareaService.obtenerTareasPorUsuarioAsignado(1L)).thenReturn(Arrays.asList(tarea));

        // Act
        ResponseEntity<List<Tarea>> response = tareaController.obtenerTareasPorUsuarioAsignado(1L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
    }

    @Test
    public void testObtenerTareasPorUsuarioAsignadoNoExistente() {
        // Arrange
        when(usuarioService.getUsuarioById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<List<Tarea>> response = tareaController.obtenerTareasPorUsuarioAsignado(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
}
