package com.login.guzpasen.controllers;

import com.login.guzpasen.models.Modulo;
import com.login.guzpasen.repositories.ModuloRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ModuloControllerTest {

    @Mock
    private ModuloRepository moduloRepository;

    @InjectMocks
    private ModuloController moduloController;

    private Modulo modulo;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        modulo = new Modulo();
        modulo.setId(1L);
        modulo.setNombre("Gestión de Tareas");
        modulo.setDescripcion("Módulo para gestionar tareas del sistema");
        modulo.setIcono("task-icon.png");
    }

    @Test
    public void testCrearModulo() {
        // Arrange
        when(moduloRepository.save(any(Modulo.class))).thenReturn(modulo);

        // Act
        ResponseEntity<Modulo> response = moduloController.crearModulo(new Modulo());

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        assertEquals("Gestión de Tareas", response.getBody().getNombre());
    }

    @Test
    public void testObtenerTodosModulos() {
        // Arrange
        when(moduloRepository.findAll()).thenReturn(Arrays.asList(modulo));

        // Act
        List<Modulo> modulos = moduloController.obtenerTodosModulos();

        // Assert
        assertNotNull(modulos);
        assertEquals(1, modulos.size());
        assertEquals("Gestión de Tareas", modulos.get(0).getNombre());
    }

    @Test
    public void testObtenerModuloPorIdExistente() {
        // Arrange
        when(moduloRepository.findById(1L)).thenReturn(Optional.of(modulo));

        // Act
        ResponseEntity<Modulo> response = moduloController.obtenerModuloPorId(1L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Gestión de Tareas", response.getBody().getNombre());
    }

    @Test
    public void testObtenerModuloPorIdNoExistente() {
        // Arrange
        when(moduloRepository.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Modulo> response = moduloController.obtenerModuloPorId(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testActualizarModuloExistente() {
        // Arrange
        Modulo moduloActualizado = new Modulo();
        moduloActualizado.setNombre("Nuevo Nombre");
        moduloActualizado.setDescripcion("Nueva Descripción");
        moduloActualizado.setIcono("nuevo-icono.png");

        when(moduloRepository.findById(1L)).thenReturn(Optional.of(modulo));
        when(moduloRepository.save(any(Modulo.class))).thenReturn(modulo);

        // Act
        ResponseEntity<Modulo> response = moduloController.actualizarModulo(1L, moduloActualizado);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(moduloRepository, times(1)).save(modulo);

        // Verificar que los campos se actualizaron correctamente
        assertEquals("Nuevo Nombre", modulo.getNombre());
        assertEquals("Nueva Descripción", modulo.getDescripcion());
        assertEquals("nuevo-icono.png", modulo.getIcono());
    }

    @Test
    public void testActualizarModuloNoExistente() {
        // Arrange
        when(moduloRepository.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Modulo> response = moduloController.actualizarModulo(99L, new Modulo());

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testEliminarModuloExistente() {
        // Arrange
        when(moduloRepository.findById(1L)).thenReturn(Optional.of(modulo));

        // Act
        ResponseEntity<?> response = moduloController.eliminarModulo(1L);

        // Assert
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        verify(moduloRepository, times(1)).delete(modulo);
    }

    @Test
    public void testEliminarModuloNoExistente() {
        // Arrange
        when(moduloRepository.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<?> response = moduloController.eliminarModulo(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(moduloRepository, never()).delete(any());
    }
}
