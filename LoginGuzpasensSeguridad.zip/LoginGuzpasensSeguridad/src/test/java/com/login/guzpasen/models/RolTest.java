package com.login.guzpasen.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RolTest {

    @Test
    public void testEnumValues() {
        // Verificar que existen los valores esperados en la enumeración
        assertEquals(3, Rol.values().length);
        assertEquals(Rol.PROFESOR, Rol.valueOf("PROFESOR"));
        assertEquals(Rol.ADMINISTRADOR, Rol.valueOf("ADMINISTRADOR"));
        assertEquals(Rol.TECNICO, Rol.valueOf("TECNICO"));
    }

    @Test
    public void testEnumToString() {
        // Verificar la representación en cadena de los valores enum
        assertEquals("PROFESOR", Rol.PROFESOR.toString());
        assertEquals("ADMINISTRADOR", Rol.ADMINISTRADOR.toString());
        assertEquals("TECNICO", Rol.TECNICO.toString());
    }
}
