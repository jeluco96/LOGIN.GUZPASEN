# Colección Postman para LoginGuzpasen

Esta carpeta contiene archivos de colección y entorno para Postman que te permitirán probar fácilmente todas las APIs del sistema LoginGuzpasen.

## Contenido

1. **LoginGuzpasen.postman_collection.json** - Colección con todas las peticiones organizadas por categorías
2. **LoginGuzpasen.postman_environment.json** - Variables de entorno para desarrollo local

## Instrucciones de uso

### Importar la colección y el entorno

1. Abre Postman
2. Haz clic en "Import" (botón en la parte superior izquierda)
3. Arrastra ambos archivos JSON o navega hasta ellos
4. Confirma la importación

### Configurar el entorno

1. En la esquina superior derecha, selecciona el entorno "LoginGuzpasen - Desarrollo"
2. Verifica que la variable `baseUrl` apunte a tu servidor de desarrollo

### Autenticación

La colección incluye un script para guardar automáticamente el token de autenticación:

1. Ejecuta la petición "Login" en la carpeta "Autenticación"
2. Si la respuesta es exitosa, el token se guardará automáticamente en la variable `authToken`
3. Las demás peticiones que requieran autenticación utilizarán este token

## Organización de las peticiones

### Usuarios
- Listar todos los usuarios
- Obtener usuario por ID
- Obtener usuario por email
- Crear usuario
- Actualizar usuario
- Eliminar usuario
- Desactivar usuario
- Restablecer contraseña

### Módulos
- Obtener módulos de un usuario
- Asignar módulo a usuario
- Eliminar módulo de usuario

### Autenticación
- Login

## Notas adicionales

- Asegúrate de que el servidor esté en ejecución antes de probar las peticiones
- Los ejemplos de datos en las peticiones son solo ilustrativos, ajústalos según tus necesidades
- Para peticiones que requieran parámetros en la URL (como IDs), modifica los valores según corresponda
