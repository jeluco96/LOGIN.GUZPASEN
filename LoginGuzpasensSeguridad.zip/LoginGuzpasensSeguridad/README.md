# Sistema de Login Guzpasen

Sistema de autenticación y gestión de usuarios desarrollado con Spring Boot y Jakarta EE.

## Características

- Autenticación de usuarios (login/registro)
- Gestión de usuarios (CRUD)
- Gestión de módulos (CRUD)
- Asignación de módulos a usuarios
- Control de acceso basado en roles (PROFESOR, ADMINISTRADOR, TECNICO)

## Requisitos

- Java 17 o superior
- Maven 3.6 o superior

## Configuración

### Base de datos

El proyecto está configurado para usar H2 (base de datos en memoria) por defecto. Para desarrollo y pruebas rápidas, no se requiere configuración adicional. Para usar otra base de datos como MySQL, modificar el archivo `application.properties`.

### Ejecución

```bash
# Clonar el repositorio
git clone [url-del-repositorio]
cd LoginGuzpasensSeguridad

# Compilar y ejecutar
./mvnw spring-boot:run
```

La aplicación estará disponible en: http://localhost:8080

## Endpoints API

### Autenticación

- `POST /api/auth/login` - Iniciar sesión
- `POST /api/auth/registro` - Registrar nuevo usuario
- `GET /api/auth/perfil?email={email}` - Obtener información del perfil

### Usuarios

- `GET /api/usuarios` - Listar todos los usuarios
- `GET /api/usuarios/{id}` - Obtener usuario por ID
- `POST /api/usuarios` - Crear usuario
- `PUT /api/usuarios/{id}` - Actualizar usuario
- `DELETE /api/usuarios/{id}` - Eliminar usuario
- `PATCH /api/usuarios/{id}/desactivar` - Desactivar usuario
- `PATCH /api/usuarios/{id}/resetPassword` - Resetear contraseña

### Módulos

- `GET /api/modulos` - Listar todos los módulos
- `GET /api/modulos/{id}` - Obtener módulo por ID
- `POST /api/modulos` - Crear módulo
- `PUT /api/modulos/{id}` - Actualizar módulo
- `DELETE /api/modulos/{id}` - Eliminar módulo

### Asignación de Módulos

- `GET /api/usuarios/{usuarioId}/modulos` - Listar módulos asignados a un usuario
- `POST /api/usuarios/{usuarioId}/modulos/{moduloId}` - Asignar módulo a usuario
- `DELETE /api/usuarios/{usuarioId}/modulos/{moduloId}` - Quitar módulo de usuario

## Seguridad

Este es un proyecto básico. Para un entorno de producción, se recomienda:

- Implementar encriptación de contraseñas (BCrypt)
- Configurar Spring Security
- Implementar autenticación con JWT
- Limitar los orígenes CORS permitidos

## Licencia

Este proyecto está licenciado bajo los términos de la licencia MIT.
